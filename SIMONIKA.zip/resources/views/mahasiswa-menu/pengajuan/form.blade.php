@extends('layout.admin-main')
@section('content')

<div class="row">
    <div class="col-md-8 col-sm-8 col-g-8">
        <div class="card">
            <div class="card-body">
                @if(session('success'))
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <i class="mdi mdi-check-all me-2"></i> {{ session('success') }}
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
                        </button>
                    </div>
                @endif
                @if(session('error'))
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <i class="mdi mdi-block-helper me-2"></i>{{ session('error') }}
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
                        </button>
                    </div>
                @endif
                <form action="{{route('mahasiswa.pengajuan-ta.store')}}" method="post" enctype="multipart/form-data">
                    @csrf
                <div class="row">
                    <div class="col-lg-12 col-md-12 col-sm-12 mb-3">
                        <div class="form-group">
                            <label for="">Pembimbing 1 <span class="text-danger">*</span></label>
                            <select name="pemb_1" id="pemb_1" onchange="cekDosen()" class="form-control select2" required>
                                <option value="">Pilih Pembimbing</option>
                                @foreach ($dataDosen as $item)
                                <option value="{{$item->id}}" {{old('pemb_1') == $item->id ? "selected='selected'" : ''}}>({{($item->kuota_pemb_1-$item->total_pemb_1)}}) {{$item->nidn}} - {{$item->name}}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12 mb-3">
                        <div class="form-group">
                            <label for="">Jenis TA <span class="text-danger">*</span></label>
                            <select name="jenis" id="jenis" class="form-control select2-1" required>
                                <option value="">Pilih Jenis</option>
                                @foreach ($dataJenis as $item)
                                <option value="{{$item->id}}" {{old('jenis') == $item->id ? "selected='selected'" : ''}}>{{$item->nama_jenis}}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12 mb-3">
                        <div class="form-group">
                            <label for="">Topik <span class="text-danger">*</span></label>
                            <select name="topik" id="topik" class="form-control select2-2" required>
                                <option value="">Pilih Topik</option>
                                @foreach ($dataTopik as $item)
                                <option value="{{$item->id}}" {{old('topik') == $item->id ? "selected='selected'" : ''}}>{{$item->nama_topik}}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12 mb-3">
                        <div class="form-group">
                            <label for="">Judul <span class="text-danger">*</span></label>
                            <input type="text" name="judul" id="judul" placeholder="Masukkan Judul ..." required class="form-control" value="{{old('judul')}}">
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12 mb-3">
                        <div class="form-group">
                            <label for="">Tipe <span class="text-danger">*</span></label>
                            <select name="tipe" id="tipe" class="form-control select2-3" required>
                                <option value="">Pilih Tipe</option>
                                <option value="K" {{old('tipe') == 'K' ? "selected='selected'" : ''}}>Kelompok</option>
                                <option value="I" {{old('tipe') == 'I' ? "selected='selected'" : ''}}>Individu</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12 mb-3" style="display: none;">
                        <div class="form-group">
                            <label for="">Dokumen Pembimbing 1 <span class="text-danger">*</span></label>
                            <input type="file" name="dokumen_pembimbing_1" id="dokumen_pembimbing_1" class="form-control">
                            @if ($errors->has('dokumen_pembimbing_1'))
                            <span class="text-danger">{{ $errors->first('dokumen_pembimbing_1') }}</span>
                            @endif
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12 mb-3">
                        <div class="form-group">
                            <label for="">Dokumen Ringkasan <span class="text-danger">*</span></label>
                            <input type="file" name="dokumen_ringkasan" id="dokumen_ringkasan" class="form-control" required>
                            @if ($errors->has('dokumen_ringkasan'))
                            <span class="text-danger">{{ $errors->first('dokumen_ringkasan') }}</span>
                            @endif
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12 mb-3">
                        <div class="form-group">
                            <label for="">Periode Mulai <span class="text-danger">*</span></label>
                            <input type="date" name="periode_mulai" id="periode_mulai" class="form-control" value="{{old('periode_mulai')}}" required>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-sm-12 mb-3">
                        <div class="form-group">
                            <label for="">Periode Akhir <span class="text-danger">*</span></label>
                            <input type="date" name="periode_akhir" id="periode_akhir" class="form-control" value="{{old('periode_akhir')}}" required>
                        </div>
                    </div>
                </div>
                <hr>
                <a href="{{route('mahasiswa.pengajuan-ta')}}" class="btn btn-secondary">Kembali</a>
                <button type="submit" class="btn btn-primary">Simpan</button>
                </form>
            </div>
        </div>
    </div>

    <div class="col-md-4 col-sm-4 col-lg-4">
        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped" id="">
                        <thead>
                            <tr>
                                <th colspan="2">Kuota Dosen</th>
                            </tr>
                            <tr>
                                <th>Nama</th>
                                <th>Kuota</th>
                            </tr>
                        </thead>
                        <tbody>
                            @foreach ($dosenKuota as $item)
                            <tr>
                                <td>{{$item->nidn}}-{{$item->nama}}</td>
                                <td>
                                    {{$item->total_pemb_1}}/{{$item->kuota_pemb_1}}
                                </td>
                            </tr>
                            @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    function cekDosen(){
        var id = $('#pemb_1').val()
        const urlCek = "{{route('mahasiswa.pengajuan-ta.cekdosen')}}"
        $.ajax({
            url: urlCek+'?pemb_1='+id, // Ganti dengan URL endpoint yang sesuai
            type: 'GET',
            dataType: 'json', // Tipe data yang diharapkan dari respons server
            success: function(data) {
                // Callback yang dijalankan jika permintaan berhasil
                console.log('Data yang diterima:', data);
                if(data == 1){
                    alert('Kuota dosen telah penuh!')
                }
            },
            error: function(xhr, status, error) {
                // Callback jika terjadi kesalahan dalam permintaan
                console.error('Terjadi kesalahan:', status, error);
            }
        });

    }
</script>
@endsection
