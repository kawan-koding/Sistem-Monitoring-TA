@include('layout.auth-header') <!-- Menyertakan file header.blade.php -->

@yield('content')

@include('layout.auth-footer') <!-- Menyertakan file footer.blade.php -->
