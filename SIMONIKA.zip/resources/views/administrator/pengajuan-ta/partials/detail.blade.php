@extends('administrator.layout.main')
@section('content')
    <div class="card">
        {{-- <div class="card-header">
            <h5  class="fw-bold">
                sistem rekomandasi pencarian buku
            </h5>
            <div class="badge badge-soft-primary font-size-12">status</div>
            <hr>
        </div>
         --}}
         <div class="card-body">
            <div class="d-flex">
                <div class="w-100">
                    <h5 class="fw-bold mb-1">{{isset($dataTA->judul) ? $dataTA->judul : '-'}}</h5>
                    <div class="d-flex gap-2 small text-muted">
                        <div class="badge rounded-pill font-size-12 px-2 {{isset($dataTA->status) ? ($dataTA->status == 'acc' ? 'badge-soft-success' : ($dataTA->status == 'draft' ? 'bg-dark-subtle text-body' : 'badge-soft-danger')) : ''}}">{{isset($dataTA->status) ? $dataTA->status : '-'}}</div>
                        |
                        <span><strong>{{isset($dataTA->topik->nama_topik) ? $dataTA->topik->nama_topik : '-'}}</strong> - {{isset($dataTA->jenis_ta->nama_jenis) ? $dataTA->jenis_ta->nama_jenis : '-'}}</span>
                    </div>
                </div>
                {{-- <button class="btn btn-rounded btn-light bx bx-dots-horizontal fs-4" style="width: 45px;height: 45px;"></button> --}}
            </div>
            <hr style="border: 1.5px solid #a1a1a1;">
            <h5 class="fw-bold m-0">Informasi</h5>
            <p class="text-muted mb-0 small">Informasi umum terkait tugas akhir</p>
            <hr>
            <table class="ms-3" cellpadding="4">
                <tr>
                    <th>Nama Mahasiswa</th>
                    <td>:</td>
                    <td>{{isset($dataTA->mahasiswa) ? $dataTA->mahasiswa->nama_mhs : '-'}}</td>
                </tr>
                <tr>
                    <th>Pembimbing 1</th>
                    <td>:</td>
                    <td>{{isset($pembimbing1) ? $pembimbing1->dosen->name : '-'}}</td>
                </tr>
                <tr>
                    <th>Pembimbing 2</th>
                    <td>:</td>
                    <td>{{isset($pembimbing2) ? $pembimbing2->dosen->name : '-'}}</td>
                </tr>
                <tr>
                    <th>Penguji 1</th>
                    <td>:</td>
                    <td>{{isset($penguji1) ? $penguji1->dosen->name : '-'}}</td>
                </tr>
                <tr>
                    <th>Penguji 2</th>
                    <td>:</td>
                    <td>{{isset($penguji2) ? $penguji2->dosen->name : '-'}}</td>
                </tr>
                <tr>
                    <th>Tipe</th>
                    <td>:</td>
                    <td>{{isset($dataTA->tipe) ? (($dataTA->tipe == 'I') ? 'Individu' : 'Kelompok') : '-'}}</td>
                </tr>
                <tr>
                    <th>Periode TA</th>
                    <td>:</td>
                    <td>{{isset($dataTA->periode_ta_id) ? $dataTA->periode_ta->nama : '-'}}</td>
                </tr>
            </table>
            <br><br>
            <div class="d-flex flex-column flex-md-row">
                <div class="w-100 px-4 py-3 fw-bold text-center border-top {{isset($dataTA->status) ? ($dataTA->status == 'draft' ? 'border-primary bg-soft-primary text-primary' : ($dataTA->status == 'acc' ? 'border-success bg-soft-success text-success' : 'border-danger bg-soft-danger text-danger')) : 'border-secondary bg-soft-secondary text-secondary'}}" style="white-space: nowrap">
                    <i class="bx {{$dataTA->status == 'acc' ? 'bx-check' : ($dataTA->status == 'reject' ? 'bx-x' : 'bx-timer')}}"></i> 
                    Pengajuan Topik
                    <br>
                    <span class="small">{{$dataTA->status == 'acc' ? 'Selesai' : ($dataTA->status == 'reject' ? 'Ditolak' : ($dataTA->status == 'draft' ? 'Sedang Berlangsung': 'Tidak Dilanjutkan'))}}</span>
                </div>
                <div class="w-100 px-4 py-3 fw-bold text-center border-top {{isset($dataTA->status_seminar) || $dataTA->status == 'acc' ? ($dataTA->status_seminar == 'revisi' || $dataTA->status == 'acc' ? 'border-primary bg-soft-primary text-primary' : ($dataTA->status_seminar == 'acc' ? 'border-success bg-soft-success text-success' : 'border-danger bg-soft-danger text-danger')) : 'border-secondary bg-soft-secondary text-secondary'}}" style="white-space: nowrap">
                    <i class="bx {{$dataTA->status_seminar == 'acc' ? 'bx-check' : ($dataTA->status_seminar == 'reject' ? 'bx-x' : 'bx-timer')}}"></i> 
                    Seminar Proposal
                    <br>
                    <span class="small">{{isset($dataTA->status_seminar) ? ($dataTA->status_seminar == 'acc' ? 'Selesai' : ($dataTA->status_seminar == 'revisi' ? 'Sedang Berlangsung' : 'Ditolak')) : ($dataTA->status == 'acc' ? 'Sedang Berlangsung' : '')}}</span>
                </div>
                <div class="w-100 px-4 py-3 fw-bold text-center border-top border-secondary bg-soft-secondary text-secondary" style="white-space: nowrap"><i class="bx bx-timer"></i> Sidang Akhir</div>
            </div>
            <br><br>
            <h5 class="fw-bold m-0">Dokumen - Dokumen</h5>
            <p class="text-muted small">Semua dokumen - dokumen pendukung tugas akhir</p>
            <hr>
            <div class="accordion" id="accordionExample">
                <div class="accordion-item">
                    <h2 class="accordion-header" id="HeadingPengajuanTA">
                        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapsePengajuanTA" aria-expanded="true" aria-controls="collapsePengajuanTA">
                            Pengajuan Tugas Akhir
                        </button>
                    </h2>
                    <div id="collapsePengajuanTA" class="accordion-collapse collapse show" aria-labelledby="headingPengajuanTA" data-bs-parent="#accordionExample">
                        <div class="accordion-body">
                            <div class="d-flex flex-wrap">
                                <div class="col-md-3 col-sm-6 col-12 border p-3 text-center">
                                    <strong>Dokumen Pembimbing 1</strong>
                                    @if (isset($dataTA->dokumen_pemb_1))
                                    <i class="mdi mdi-file-pdf-box-outline text-danger d-block" style="font-size: 56px;"></i>
                                    <a href="{{asset('storage/files/tugas-akhir/'. $dataTA->dokumen_pemb_1)}}" target="_blank" class="btn btn-secondary btn-sm"><i class="bx bx-show-alt"></i> Lihat Dokumen</a>
                                    @else
                                    <br><br>
                                    <br><br><br>
                                    <p class="text-muted"><i class="text-danger">*</i>) Belum memiliki dokumen</p>
                                    @endif
                                </div>
                                <div class="col-md-3 col-sm-6 col-12 border p-3 text-center">
                                    <strong>Dokumen Pembimbing 2</strong>
                                    @if (isset($dataTA->file_persetujuan_pemb_2))
                                    <i class="mdi mdi-file-pdf-box-outline text-danger d-block" style="font-size: 56px;"></i>
                                    <a href="{{asset('storage/files/tugas-akhir/'. $dataTA->file_persetujuan_pemb_2)}}" target="_blank" class="btn btn-secondary btn-sm"><i class="bx bx-show-alt"></i> Lihat Dokumen</a>
                                    @else    
                                    <br><br>
                                    <br><br><br>
                                    <p class="text-muted"><i class="text-danger">*</i>) Belum memiliki dokumen</p>
                                    @endif
                                </div>
                                <div class="col-md-3 col-sm-6 col-12 border p-3 text-center">
                                    <strong>Dokumen Ringkasan</strong>
                                    @if (isset($dataTA->dokumen_ringkasan))
                                    <i class="mdi mdi-file-pdf-box-outline text-danger d-block" style="font-size: 56px;"></i>
                                    <a href="{{asset('storage/files/tugas-akhir/'. $dataTA->dokumen_ringkasan)}}" target="_blank" class="btn btn-secondary btn-sm"><i class="bx bx-show-alt"></i> Lihat Dokumen</a>
                                    @else
                                    <br><br>
                                    <br><br><br>
                                    <p class="text-muted"><i class="text-danger">*</i>) Belum memiliki dokumen</p>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="accordion-item">
                    <h2 class="accordion-header" id="HeadingSeminar">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseSeminar" aria-expanded="true" aria-controls="collapseSeminar">
                            Seminar Proposal
                        </button>
                    </h2>
                    <div id="collapseSeminar" class="accordion-collapse collapse" aria-labelledby="headingSeminar" data-bs-parent="#accordionExample">
                        <div class="accordion-body">
                            <div class="d-flex flex-wrap">
                                <div class="col-md-3 col-sm-6 col-12 border p-3 text-center">
                                    <strong>Lembar Penilaian</strong>
                                    <br><br>
                                    <br><br><br>
                                    <p class="text-muted"><i class="text-danger">*</i>) Belum memiliki dokumen</p>
                                </div>
                                <div class="col-md-3 col-sm-6 col-12 border p-3 text-center">
                                    <strong>Rekapitulasi Nilai</strong>
                                    <br><br>
                                    <br><br><br>
                                    <p class="text-muted"><i class="text-danger">*</i>) Belum memiliki dokumen</p>
                                </div>
                                <div class="col-md-3 col-sm-6 col-12 border p-3 text-center">
                                    <strong>Berita Acara</strong>
                                    <br><br>
                                    <br><br><br>
                                    <p class="text-muted"><i class="text-danger">*</i>) Belum memiliki dokumen</p>
                                </div>
                                <div class="col-md-3 col-sm-6 col-12 border p-3 text-center">
                                    <strong>Lembar Revisi</strong>
                                    <br><br>
                                    <br><br><br>
                                    <p class="text-muted"><i class="text-danger">*</i>) Belum memiliki dokumen</p>
                                </div>
                                <div class="col-md-3 col-sm-6 col-12 border p-3 text-center">
                                    <strong>File Proposal</strong>
                                    @if (isset($dataTA->file_proposal))
                                    <i class="mdi mdi-file-pdf-box-outline text-danger d-block" style="font-size: 56px;"></i>
                                    <a href="{{asset('storage/files/tugas-akhir/'. $dataTA->file_propsal)}}" target="_blank" class="btn btn-secondary btn-sm"><i class="bx bx-show-alt"></i> Lihat Dokumen</a>
                                    @else    
                                    <br><br>
                                    <br><br><br>
                                    <p class="text-muted"><i class="text-danger">*</i>) Belum memiliki dokumen</p>
                                    @endif
                                </div>
                                <div class="col-md-3 col-sm-6 col-12 border p-3 text-center">
                                    <strong>Lembar Pengesahan</strong>
                                    @if (isset($dataTA->file_pengesahan))
                                    <i class="mdi mdi-file-pdf-box-outline text-danger d-block" style="font-size: 56px;"></i>
                                    <a href="{{asset('storage/files/tugas-akhir/'. $dataTA->file_pengesahan)}}" target="_blank" class="btn btn-secondary btn-sm"><i class="bx bx-show-alt"></i> Lihat Dokumen</a>
                                    @else    
                                    <br><br>
                                    <br><br><br>
                                    <p class="text-muted"><i class="text-danger">*</i>) Belum memiliki dokumen</p>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="accordion-item">
                    <h2 class="accordion-header" id="HeadingSidang">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseSidang" aria-expanded="true" aria-controls="collapseSidang">
                            Sidang Akhir
                        </button>
                    </h2>
                    <div id="collapseSidang" class="accordion-collapse collapse" aria-labelledby="headingSidang" data-bs-parent="#accordionExample">
                        <div class="accordion-body">
                            <div class="d-flex flex-wrap">
                                <div class="col-md-3 col-sm-6 col-12 border p-3 text-center">
                                    <strong>Lembar Penilaian</strong>
                                    <br><br>
                                    <br><br><br>
                                    <p class="text-muted"><i class="text-danger">*</i>) Belum memiliki dokumen</p>
                                </div>
                                <div class="col-md-3 col-sm-6 col-12 border p-3 text-center">
                                    <strong>Rekapitulasi Nilai</strong>
                                    <br><br>
                                    <br><br><br>
                                    <p class="text-muted"><i class="text-danger">*</i>) Belum memiliki dokumen</p>
                                </div>
                                <div class="col-md-3 col-sm-6 col-12 border p-3 text-center">
                                    <strong>Berita Acara</strong>
                                    <br><br>
                                    <br><br><br>
                                    <p class="text-muted"><i class="text-danger">*</i>) Belum memiliki dokumen</p>
                                </div>
                                <div class="col-md-3 col-sm-6 col-12 border p-3 text-center">
                                    <strong>Lembar Revisi</strong>
                                    <br><br>
                                    <br><br><br>
                                    <p class="text-muted"><i class="text-danger">*</i>) Belum memiliki dokumen</p>
                                </div>
                                <div class="col-md-3 col-sm-6 col-12 border p-3 text-center">
                                    <strong>File Laporan</strong>
                                    @if (isset($dataTA->file_proposal))
                                    <i class="mdi mdi-file-pdf-box-outline text-danger d-block" style="font-size: 56px;"></i>
                                    <a href="{{asset('storage/files/tugas-akhir/'. $dataTA->file_propsal)}}" target="_blank" class="btn btn-secondary btn-sm"><i class="bx bx-show-alt"></i> Lihat Dokumen</a>
                                    @else    
                                    <br><br>
                                    <br><br><br>
                                    <p class="text-muted"><i class="text-danger">*</i>) Belum memiliki dokumen</p>
                                    @endif
                                </div>
                                <div class="col-md-3 col-sm-6 col-12 border p-3 text-center">
                                    <strong>Lembar Pengesahan</strong>
                                    @if (isset($dataTA->file_pengesahan))
                                    <i class="mdi mdi-file-pdf-box-outline text-danger d-block" style="font-size: 56px;"></i>
                                    <a href="{{asset('storage/files/tugas-akhir/'. $dataTA->file_pengesahan)}}" target="_blank" class="btn btn-secondary btn-sm"><i class="bx bx-show-alt"></i> Lihat Dokumen</a>
                                    @else    
                                    <br><br>
                                    <br><br><br>
                                    <p class="text-muted"><i class="text-danger">*</i>) Belum memiliki dokumen</p>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
         </div>
    </div>
@endsection