<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12 col-sm-12 col-g-12">
        <div class="card">
            <div class="card-body">
              <div class="d-flex flex-column flex-md-row justify-content-between align-items-start align-items-md-center gap-3 mb-3">
                    
                    <form action="" class="d-flex gap-2 flex-column flex-md-row align-items-start">
                        <select name="program_studi" id="program_studi" class="form-control" onchange="this.form.submit()">
                            <option selected disabled hidden>Filter Program Studi</option>
                            <option value="semua" <?php echo e(request('program_studi') == 'semua' ? 'selected' : ''); ?>>Semua Program Studi</option>
                            <?php $__currentLoopData = $prodi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($p->id); ?>" <?php echo e(request('program_studi') == $p->id ? 'selected' : ''); ?>><?php echo e($p->nama); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <select name="periode" class="form-control" onchange="this.form.submit()">
                            <option selected disabled hidden>Filter Periode</option>
                            <option value="semua" <?php echo e(request('periode') == 'semua'  ? 'selected' : ''); ?>>Semua</option>
                            <?php $__currentLoopData = $periode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($item->id); ?>" <?php echo e(request('periode') == $item->id ? 'selected' : ''); ?>>
                                    <?php echo e($item->programStudi->display); ?> - (<?php echo e($item->nama); ?>)
                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </form>

                    
                    <?php if(auth()->user()->hasRole('Developer') || auth()->user()->hasRole('Admin')): ?>
                        <div class="d-flex flex-column flex-md-row gap-2">
                            <button id="backup-btn" class="btn btn-success"><i class="bx bx-cloud-download me-2"></i>Backup Database</button>
                        </div>
                    <?php endif; ?>
                </div>

                <hr>
                <div class="table-responsive">
                    <table class="table table-striped" id="datatable">
                        <thead>
                            <tr>
                                <th width="5%">No</th>
                                <th width="20%">Mahasiswa</th>
                                <th width="40%">Judul</th>
                                <th width="20%">Dosen</th>
                                <th width="10%">Periode</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td>
                                        <p class="m-0 badge rounded-pill bg-primary-subtle text-primary small"><?php echo e($item->mahasiswa->programStudi->display); ?></p>
                                        <a href="#" class="m-0" data-bs-toggle="modal" data-bs-target="#mahasiswaModal<?php echo e($key); ?>">
                                            <p class="fw-bold m-0"><?php echo e($item->mahasiswa->nama_mhs); ?></p>
                                        </a>
                                        <div class="modal fade" id="mahasiswaModal<?php echo e($key); ?>" tabindex="-1" aria-labelledby="mahasiswaModalLabel<?php echo e($key); ?>" aria-hidden="true">
                                            <div class="modal-dialog modal-lg modal-dialog-centered">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="mahasiswaModalLabel<?php echo e($key); ?>">Biodata Mahasiswa</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <div class="row">
                                                            <div class="col-md-4 text-center">
                                                                <img src="<?php echo e($item->mahasiswa->user->image == null ? 'https://ui-avatars.com/api/?background=random&name=' . $item->mahasiswa->user->name : asset('storage/images/users/' . $item->mahasiswa->user->image)); ?>"
                                                                    alt="Foto Mahasiswa" class="img-fluid rounded">
                                                            </div>
                                                            <div class="col-md-8">
                                                                <table class="table table-sm table-borderless">
                                                                    <tr>
                                                                        <th>Nama</th>
                                                                        <td><?php echo e($item->mahasiswa->nama_mhs ?? '-'); ?>

                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <th>NIM</th>
                                                                        <td><?php echo e($item->mahasiswa->nim ?? '-'); ?>

                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <th>Kelas</th>
                                                                        <td><?php echo e($item->mahasiswa->kelas ?? '-'); ?>

                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <th>Prodi</th>
                                                                        <td><?php echo e($item->mahasiswa->programStudi->display ?? '-'); ?>

                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <th>Telepon</th>
                                                                        <td><?php echo e($item->mahasiswa->telp ?? '-'); ?>

                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <th>Email</th>
                                                                        <td><?php echo e($item->mahasiswa->email ?? '-'); ?>

                                                                        </td>
                                                                    </tr>
                                                                </table>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <p class="m-0 p-0 text-muted small">NIM : <?php echo e($item->mahasiswa->nim); ?></p>
                                    </td>
                                    <td>
                                        <span class="badge badge-soft-primary small mb-1 fw-bold"><?php echo e(isset($item->tipe) ? ($item->tipe == 'I' ? 'Individu' : 'Kelompok') : '-'); ?></span>
                                        <p class="m-0 small"><strong><?php echo e($item->judul ?? '-'); ?></strong></p>
                                        <p class="m-0 text-muted font-size-12 small"><?php echo e($item->topik->nama_topik ?? '-'); ?> - <?php echo e($item->jenis_ta->nama_jenis ?? '-'); ?></p>
                                    </td>
                                    <td>
                                        <p class="fw-bold small m-0">Pembimbing</p>
                                        <ol>
                                            <?php $__currentLoopData = $item->bimbing_uji->where('jenis', 'pembimbing')->sortBy('urut'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pembimbing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li class="small"><?php echo e($pembimbing->dosen->name); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ol>
                                        <p class="fw-bold small m-0">Penguji</p>
                                        <ol>
                                            <?php $__currentLoopData = $item->bimbing_uji->where('jenis', 'penguji')->sortBy('urut'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penguji): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <li class="small"><?php echo e($penguji->dosen->name); ?></li>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ol>
                                        <p class="fw-bold small m-0">Pengganti</p>
                                        <ol>
                                            <?php for($i = 0; $i < 2; $i++): ?>
                                                <?php if(isset($item->tugas_akhir->bimbing_uji) && $item->tugas_akhir->bimbing_uji()->where('jenis', 'pengganti')->where('urut', $i + 1)->count() > 0): ?>
                                                    <?php $__currentLoopData = $item->tugas_akhir->bimbing_uji()->where('jenis', 'pengganti')->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $peng): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($peng->jenis == 'pengganti' && $peng->urut == 1 && $i == 0): ?>
                                                            <li class="small"><?php echo e($peng->dosen->name ?? '-'); ?></li>
                                                        <?php endif; ?>
                                                        <?php if($peng->jenis == 'pengganti' && $peng->urut == 2 && $i == 1): ?>
                                                            <li class="small"><?php echo e($peng->dosen->name ?? '-'); ?></li>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php else: ?>
                                                    <li class="small">-</li>
                                                <?php endif; ?>
                                            <?php endfor; ?>
                                        </ol>
                                    </td>
                                    <td><p class="small"><?php echo e($item->periode_ta->nama ?? '-'); ?></p></td>
                                    <td>
                                        <a href="<?php echo e(route('apps.archives.show', $item->id)); ?>" class="btn btn-sm btn-outline-warning mb-1" title="Detail"><i class="bx bx-show"></i></a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('js'); ?>

<script>
    $('#backup-btn').on('click', function (e) {
        e.preventDefault();
        let $btn = $(this);
        $btn.html('<i class="bx bx-loader bx-spin font-size-16 align-middle me-2"></i>Loading...');
        $btn.prop('disabled', true);

        $.ajax({
            url: "<?php echo e(route('apps.backup-database')); ?>",
            type: "POST",
            headers: {
                'X-CSRF-TOKEN': '<?php echo e(csrf_token()); ?>'
            },
            success: function (response) {
                Swal.fire({
                    icon: 'success',
                    title: 'Backup Sukses!',
                    text: 'File akan segera diunduh...',
                    timer: 2000,
                    showConfirmButton: false
                });

                let link = document.createElement('a');
                link.href = 'data:application/sql;base64,' + response.filedata;
                link.download = response.filename;
                link.click();

                $btn.html('<i class="bx bx-cloud-download me-2"></i>Backup Database');
                $btn.prop('disabled', false);
            },
            error: function (xhr) {
                Swal.fire({
                    icon: 'error',
                    title: 'Gagal',
                    text: xhr.responseJSON?.message || 'Terjadi kesalahan saat backup.'
                });
                $btn.html('<i class="bx bx-cloud-download me-2"></i>Backup Database');
                $btn.prop('disabled', false);
            }
        });
    });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('administrator.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Sistem-Monitoring-TA\resources\views/administrator/archive/index.blade.php ENDPATH**/ ?>