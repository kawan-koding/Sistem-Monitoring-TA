

<?php $__env->startSection('app'); ?>

<div class="account-pages my-5 pt-sm-5">
    <div class="container">
        <div class="row justify-content-center">
            <?php if(in_array('Admin', $roles)): ?> 
            <div class="col-lg-4">
                <div class="card">
                    <div class="card-body text-center">
                      <i class="fas fa-user-tie card-icon"></i>
                      <h5 class="card-title mt-3">Admin</h5>
                      <p class="card-text">Masuk sebagai admin.</p>
                      <a href="<?php echo e(route('apps.switcher', ['role' => 'Admin'])); ?>" class="btn btn-primary">Masuk</a>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <?php if(in_array('Kajur', $roles)): ?> 
            <div class="col-lg-4">
                <div class="card">
                    <div class="card-body text-center">
                      <i class="fas fa-user-tie card-icon"></i>
                      <h5 class="card-title mt-3">Kajur</h5>
                      <p class="card-text">Masuk sebagai kajur.</p>
                      <a href="<?php echo e(route('apps.switcher', ['role' => 'Kajur'])); ?>" class="btn btn-primary">Masuk</a>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <?php if(in_array('Kaprodi', $roles)): ?> 
            <div class="col-lg-4">
                <div class="card">
                    <div class="card-body text-center">
                      <i class="fas fa-user-tie card-icon"></i>
                      <h5 class="card-title mt-3">Kaprodi</h5>
                      <p class="card-text">Masuk sebagai kaprodi.</p>
                      <a href="<?php echo e(route('apps.switcher', ['role' => 'Kaprodi'])); ?>" class="btn btn-primary">Masuk</a>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <?php if(in_array('Dosen', $roles)): ?> 
            <div class="col-lg-4">
                <div class="card">
                    <div class="card-body text-center">
                      <i class="fas fa-user-tie card-icon"></i>
                      <h5 class="card-title mt-3">Dosen</h5>
                      <p class="card-text">Masuk sebagai dosen.</p>
                      <a href="<?php echo e(route('apps.switcher', ['role' => 'Dosen'])); ?>" class="btn btn-primary">Masuk</a>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <?php if(in_array('Mahasiswa', $roles)): ?> 
            <div class="col-lg-4">
                <div class="card">
                    <div class="card-body text-center">
                      <i class="fas fa-user-tie card-icon"></i>
                      <h5 class="card-title mt-3">Mahasiswa</h5>
                      <p class="card-text">Masuk sebagai mahasiswa.</p>
                      <a href="<?php echo e(route('apps.switcher', ['role' => 'Mahasiswa'])); ?>" class="btn btn-primary">Masuk</a>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <?php if(in_array('Teknisi', $roles)): ?> 
            <div class="col-lg-4">
                <div class="card">
                    <div class="card-body text-center">
                      <i class="fas fa-code card-icon"></i>
                      <h5 class="card-title mt-3">Teknisi</h5>
                      <p class="card-text">Masuk sebagai teknisi.</p>
                      <a href="<?php echo e(route('apps.switcher', ['role' => 'Teknisi'])); ?>" class="btn btn-primary">Masuk</a>
                    </div>
                </div>
            </div>
            <?php endif; ?>

            <?php if(in_array('Developer', $roles)): ?> 
            <div class="col-lg-4">
                <div class="card">
                    <div class="card-body text-center">
                      <i class="fas fa-code card-icon"></i>
                      <h5 class="card-title mt-3">Developer</h5>
                      <p class="card-text">Masuk sebagai pengembang.</p>
                      <a href="<?php echo e(route('apps.switcher', ['role' => 'Developer'])); ?>" class="btn btn-primary">Masuk</a>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('administrator.layout.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Sistem-Monitoring-TA\resources\views/auth/switch.blade.php ENDPATH**/ ?>