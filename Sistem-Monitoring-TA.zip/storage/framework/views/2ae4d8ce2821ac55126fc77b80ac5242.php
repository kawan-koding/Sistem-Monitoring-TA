<?php if(getInfoLogin()->hasRole('Mahasiswa')): ?>
    <div class="card shadow-sm mb-4">
        <div class="card-body">
            <div class="row align-items-center">
                <div class="col-8">
                    <h5 class="m-0">Cetak Lembar Penilaian</h5>
                    <p class="text-muted small m-0">Lakukan cetak seluruh lembar penilaian.</p>
                </div>
                <div class="col-4 text-end">
                    <a href="<?php echo e(route('apps.jadwal-sidang.nilai', $data->id)); ?>" target="_blank"
                        class="btn btn-outline-dark btn-sm"><i class="bx bx-printer"></i> Cetak Lembar Penilaian</a>
                </div>
            </div>

        </div>
    </div>

    <?php $__currentLoopData = $bimbingUjis->whereIn('jenis', ['pembimbing', 'penguji']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bimbingUji): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="card shadow-sm mb-4">
            <div class="card-body">
                <div class="col-12 text-center mb-4">
                    <h5 class="mb-0 fw-bold">Lembar Penilaian</h5>
                    <?php if(
                        $bimbingUji->jenis == 'penguji' &&
                            $bimbingUjis->where('jenis', 'pengganti')->where('urut', $bimbingUji->urut)->count() > 0): ?>
                        <?php
                            $item = $bimbingUjis
                                ->where('jenis', 'pengganti')
                                ->where('urut', $bimbingUji->urut)
                                ->first();
                        ?>
                        <strong>(<?php echo e($item->dosen->name); ?>)</strong>
                        <p class="text-muted small"><?php echo e(ucfirst('penguji')); ?> <?php echo e($item->urut); ?></p>
                    <?php else: ?>
                        <strong>(<?php echo e($bimbingUji->dosen->name); ?>)</strong>
                        <p class="text-muted small"><?php echo e(ucfirst($bimbingUji->jenis)); ?> <?php echo e($bimbingUji->urut); ?></p>
                    <?php endif; ?>
                </div>
                <table class="table" width="100%">
                    <thead class="bg-light">
                        <th>No.</th>
                        <th>Aspek</th>
                        <th>Angka</th>
                        <th>Huruf</th>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $kategoriNilais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td width="25"><?php echo e($key + 1); ?>.</td>
                                <td><?php echo e($category->nama); ?></td>
                                <?php if(
                                    $bimbingUji->jenis == 'penguji' &&
                                        $bimbingUjis->where('jenis', 'pengganti')->where('urut', $bimbingUji->urut)->count() > 0): ?>
                                    <?php
                                        $item = $bimbingUjis
                                            ->where('jenis', 'pengganti')
                                            ->where('urut', $bimbingUji->urut)
                                            ->first();
                                    ?>
                                    <td><?php echo e($item->penilaian->where('kategori_nilai_id', $category->id)->where('type', 'Sidang')->first()->nilai ?? '0'); ?>

                                    </td>
                                    <td><?php echo e(grade($item->penilaian->where('kategori_nilai_id', $category->id)->where('type', 'Sidang')->first()->nilai ?? 0)); ?>

                                    </td>
                                <?php else: ?>
                                    <td><?php echo e($bimbingUji->penilaian->where('kategori_nilai_id', $category->id)->where('type', 'Sidang')->first()->nilai ?? '0'); ?>

                                    </td>
                                    <td><?php echo e(grade($bimbingUji->penilaian->where('kategori_nilai_id', $category->id)->where('type', 'Sidang')->first()->nilai ?? 0)); ?>

                                    </td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot class="bg-light">
                        <?php if(
                            $bimbingUji->jenis == 'penguji' &&
                                $bimbingUjis->where('jenis', 'pengganti')->where('urut', $bimbingUji->urut)->count() > 0): ?>
                            <?php
                                $item = $bimbingUjis
                                    ->where('jenis', 'pengganti')
                                    ->where('urut', $bimbingUji->urut)
                                    ->first();
                            ?>
                            <tr>
                                <td colspan="2">Total Nilai Angka</td>
                                <td colspan="2">
                                    <?php echo e(number_format($item->penilaian->sum('nilai') > 0 ? $item->penilaian->where('type', 'Sidang')->sum('nilai') / $kategoriNilais->count() : 0, 2, '.', '.')); ?>

                                </td>
                            </tr>
                            <tr>
                                <td colspan="2">Total Nilai Huruf</td>
                                <td colspan="2">
                                    <?php echo e(grade($item->penilaian->sum('nilai') > 0 ? $item->penilaian->where('type', 'Sidang')->sum('nilai') / $kategoriNilais->count() : 0)); ?>

                                </td>
                            </tr>
                        <?php else: ?>
                            <tr>
                                <td colspan="2">Total Nilai Angka</td>
                                <td colspan="2">
                                    <?php echo e(number_format($bimbingUji->penilaian->sum('nilai') > 0 ? $bimbingUji->penilaian->where('type', 'Sidang')->sum('nilai') / $kategoriNilais->count() : 0, 2, '.', '.')); ?>

                                </td>
                            </tr>
                            <tr>
                                <td colspan="2">Total Nilai Huruf</td>
                                <td colspan="2">
                                    <?php echo e(grade($bimbingUji->penilaian->sum('nilai') > 0 ? $bimbingUji->penilaian->where('type', 'Sidang')->sum('nilai') / $kategoriNilais->count() : 0)); ?>

                                </td>
                            </tr>
                        <?php endif; ?>
                    </tfoot>
                </table>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php else: ?>
    <div class="card shadow-sm mb-4">
        <div class="card-body">
            <div class="col-12 mb-4">
                <h5 class="mb-0 fw-bold">Lembar Penilaian</h5>
                <strong><?php echo e(getInfoLogin()->userable->name); ?>

                    (<?php echo e(ucfirst(str_replace('pengganti', 'penguji', $data->tugas_akhir->bimbing_uji()->where('dosen_id', getInfoLogin()->userable_id)->first()->jenis))); ?>

                    <?php echo e($data->tugas_akhir->bimbing_uji()->where('dosen_id', getInfoLogin()->userable_id)->first()->urut); ?>)</strong>
                <p class="text-muted small">Berikan nilai untuk :
                    <strong><?php echo e($data->tugas_akhir->mahasiswa->nama_mhs); ?></strong></p>
            </div>
            <form action="<?php echo e(route('apps.jadwal-sidang.nilai', $data->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <table class="table" width="100%">
                    <thead class="bg-light">
                        <th>No.</th>
                        <th>Aspek</th>
                        <th>Angka</th>
                        <th>Huruf</th>
                    </thead>
                    <tbody>
                        <?php if($kategoriNilais->count() > 0): ?>
                            <?php $__currentLoopData = $kategoriNilais; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td width="25"><?php echo e($loop->iteration); ?>.</td>
                                    <td><?php echo e($item->nama); ?></td>
                                    <td>
                                        <input type="text" name="nilai_<?php echo e($item->id); ?>"
                                            data-grade-display="#grade-display-<?php echo e($item->id); ?>"
                                            class="form-control numberOnly text-center w-25"
                                            value="<?php echo e($nilais->where('kategori_nilai_id', $item->id)->first()->nilai ?? ''); ?>">
                                    </td>
                                    <td id="grade-display-<?php echo e($item->id); ?>">
                                        <?php echo e(grade($nilais->where('kategori_nilai_id', $item->id)->first()->nilai ?? 0)); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="4" class="text-center">Belum ada aspek nilai.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                    <tfoot class="bg-light">
                        <tr>
                            <td colspan="2">Total Nilai Angka</td>
                            <td colspan="2" class="average-display">
                                <?php echo e(number_format($nilais->sum('nilai') > 0 ? $nilais->sum('nilai') / $nilais->count() : 0, 2, '.', ',')); ?>

                            </td>
                        </tr>
                        <tr>
                            <td colspan="2">Total Nilai Huruf</td>
                            <td colspan="2" class="average-grade-display">
                                <?php echo e(grade($nilais->sum('nilai') > 0 ? $nilais->sum('nilai') / $nilais->count() : 0)); ?>

                            </td>
                        </tr>
                    </tfoot>
                </table>
                <div class="text-end mt-4">
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </div>
            </form>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH C:\laragon\www\Sistem-Monitoring-TA\resources\views/administrator/jadwal-sidang/partials/rating-tab.blade.php ENDPATH**/ ?>