<?php if(getInfoLogin()->hasRole('Dosen') && $data->tugas_akhir->bimbing_uji()->where('dosen_id', getInfoLogin()->userable_id)->first()->jenis == 'pembimbing' || getInfoLogin()->hasRole('Mahasiswa')): ?>
    <div class="row align-items-center">
        <div class="col-md-8 col-12">
            <h5 class="fw-bold mb-0">Lembar Revisi</h5>
            <p class="text-muted small m-0">Lihat uraian revisi yang telah diberikan oleh dosen penguji.</p>
        </div>
        <?php if(getInfoLogin()->hasRole('Mahasiswa')): ?>        
            <?php
                $penguji1 = $data->tugas_akhir->bimbing_uji()->where('jenis', 'penguji')->where('urut', 1)->with('revisi')->first();
                $penguji2 = $data->tugas_akhir->bimbing_uji()->where('jenis', 'penguji')->where('urut', 2)->with('revisi')->first();
                $pengganti1 = $data->tugas_akhir->bimbing_uji()->where('jenis', 'pengganti')->where('urut', 1)->with('revisi')->first();
                $pengganti2 = $data->tugas_akhir->bimbing_uji()->where('jenis', 'pengganti')->where('urut', 2)->with('revisi')->first();
                $revisi1 = optional($pengganti1 ?? $penguji1)->revisi->where('type', 'Sidang')->first();
                $revisi2 = optional($pengganti2 ?? $penguji2)->revisi->where('type', 'Sidang')->first();

                $validRevisions = collect([$revisi1, $revisi2])->filter();
                $allValid = $validRevisions->every(fn($rev) => $rev->is_valid == true);
            ?>

            <?php if($validRevisions->isNotEmpty() && $allValid): ?> 
                <div class="col-md-4 col-12 text-center">
                    <a href="<?php echo e(route('apps.jadwal-sidang.revisi', $data->id)); ?>" target="_blank" class="btn btn-outline-dark btn-sm"><i class="bx bx-printer"></i> Cetak Lembar Revisi</a>
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>
    <hr>
    <table class="table" width="100%">
        <thead class="bg-light">
            <th width="25">No.</th>
            <th>Penguji</th>
            <th>Uraian</th>
            <th></th>
        </thead>
        <tbody>
            <?php
                $penguji = $data->tugas_akhir->bimbing_uji()->whereIn('jenis', ['pengganti', 'penguji'])->orderBy('urut', 'asc')->get();
                $penguji = $penguji->filter(fn ($item) => $item->jenis == 'penguji' && $penguji->where('jenis', 'pengganti')->where('urut', $item->urut)->count() == 0 || $item->jenis == 'pengganti');
            ?>
            <?php $__currentLoopData = $penguji; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($loop->iteration); ?></td>
                    <td style="white-space: nowrap">
                        <strong><?php echo e($item->dosen->name); ?></strong>
                        <p class="m-0 text-muted small">Penguji <?php echo e($item->urut); ?></p>
                        <?php
                            $revisi = $item->revisi()->where('type', 'Sidang')->first();
                        ?>
                        <span class="badge small <?php echo e(isset($revisi->is_valid) ? ($revisi->is_valid ? 'badge-soft-success' : 'badge-soft-danger') : 'badge-soft-secondary'); ?> ">
                            <?php echo e(isset($revisi->is_valid) ? ($revisi->is_valid ? 'Sudah Divalidasi' : 'Belum Divalidasi') : '-'); ?>

                        </span>
                    </td>
                    <td>
                        <?php echo is_null($item->revisi()->where('type', 'Sidang')->first()) ? '-' : $item->revisi()->where('type', 'Sidang')->first()->catatan; ?>

                    </td>
                        <?php
                           $mentors = $item->tugas_akhir->bimbing_uji()->where('jenis', 'pembimbing')->pluck('dosen_id')->toArray();
                        ?>

                    <td>
                        <?php if(in_array(getInfoLogin()->userable_id, $mentors)): ?>
                            <?php if(!is_null($item->revisi()->where('type', 'Sidang')->first()) && $item->revisi()->where('type', 'Sidang')->first()->is_mentor_validation): ?>
                                <button class="btn btn-success btn-small">Sudah Divalidasi</button>
                            <?php endif; ?>
                            <?php if(!is_null($item->revisi()->where('type', 'Sidang')->first()) && !$item->revisi()->where('type', 'Sidang')->first()->is_mentor_validation): ?>
                                <a href="<?php echo e(route('apps.jadwal-sidang.mentor-validation', $item->revisi()->where('type', 'Sidang')->first()->id)); ?>" class="btn btn-outline-primary btn-sm"><i class="bx bx-check"></i> Validasi Revisi</a>
                            <?php endif; ?>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php else: ?>
    <div class="row align-items-center">
        <h5 class="fw-bold mb-0">Lembar Revisi</h5>
        <strong class="mb-0"><?php echo e(getInfoLogin()->userable->name); ?> (Penguji <?php echo e($data->tugas_akhir->bimbing_uji()->where('dosen_id', getInfoLogin()->userable_id)->first()->urut); ?>)</strong>
        <p class="text-muted small m-0">Tuliskan revisi untuk:
            <?php
                $bimbingUji = $data->tugas_akhir->bimbing_uji()->where('dosen_id', getInfoLogin()->userable_id)->first();
                $revisiSidang = $bimbingUji ? $bimbingUji->revisi()->where('type', 'Sidang')->first() : null;
            ?>
            <strong><?php echo e($data->tugas_akhir->mahasiswa->nama_mhs); ?></strong>
            <?php if($revisiSidang && !$revisiSidang->is_mentor_validation): ?>
                <span class="badge badge-soft-secondary">Belum divalidasi pembimbing</span>
            <?php elseif($revisiSidang && $revisiSidang->is_valid): ?>
                <span class="badge badge-soft-success">Sudah Revisi</span>
            <?php endif; ?>
    </div>
    <hr>
    <div class="">
        <form action="<?php echo e(route('apps.jadwal-sidang.revisi', $data->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <textarea name="revisi" id="elm1"><?php echo e(!is_null($data->tugas_akhir->bimbing_uji()->where('dosen_id', getInfoLogin()->userable_id)->first()->revisi()->where('type', 'Sidang')->first())? $data->tugas_akhir->bimbing_uji()->where('dosen_id', getInfoLogin()->userable_id)->first()->revisi()->where('type', 'Sidang')->first()->catatan: ''); ?></textarea>
            <br>
            <div class="text-end">
                <?php if(!is_null($data->tugas_akhir->bimbing_uji()->where('dosen_id', getInfoLogin()->userable_id)->first()->revisi()->where('type', 'Sidang')->first()) && $data->tugas_akhir->bimbing_uji()->where('dosen_id', getInfoLogin()->userable_id)->first()->revisi()->where('type', 'Sidang')->first()->is_mentor_validation && !$data->tugas_akhir->bimbing_uji()->where('dosen_id', getInfoLogin()->userable_id)->first()->revisi()->where('type', 'Sidang')->first()->is_valid): ?>
                    <a href="<?php echo e(route('apps.jadwal-sidang.revision-valid', $data->tugas_akhir->bimbing_uji()->where('dosen_id', getInfoLogin()->userable_id)->first()->revisi()->where('type', 'Sidang')->first()->id)); ?>" class="btn btn-success">Sudah Revisi</a>
                <?php endif; ?>
                <button class="btn btn-primary" type="submit">Simpan</button>
            </div>
        </form>
    </div>
<?php endif; ?>
<?php /**PATH C:\laragon\www\Sistem-Monitoring-TA\resources\views/administrator/jadwal-sidang/partials/revision-tab.blade.php ENDPATH**/ ?>