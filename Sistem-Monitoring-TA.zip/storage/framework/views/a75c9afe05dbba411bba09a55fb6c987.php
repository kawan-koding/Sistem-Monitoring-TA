

<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-md-12 col-sm-12 col-g-12">
        <div class="card">
            <div class="card-body">
                <div class="table-responsive">
                    <table class="table table-striped" id="datatable">
                        <thead>
                            <tr>
                                <th width="5%">No</th>
                                <th>Nama Dosen</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td>
                                    <div class="d-flex align-items-start">
                                        <div class="me-3">
                                            <a href="#" data-bs-toggle="modal" data-bs-target="#imageModal-<?php echo e($item->id); ?>">
                                                <img src="<?php echo e(asset('storage/images/users/' . ($item->user->image ?? 'default.png'))); ?>" alt="Profile" class="rounded-circle" style="width: 80px; height: 80px; cursor: pointer;">
                                            </a>
                                        </div>  
                                        <div class="modal fade" id="imageModal-<?php echo e($item->id); ?>" tabindex="-1" aria-labelledby="imageModalLabel" aria-hidden="true">
                                            <div class="modal-dialog modal-dialog-centered">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="imageModalLabel"><?php echo e($item->name); ?></h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body text-center">
                                                        <img src="<?php echo e(asset('storage/images/users/' . ($item->user->image ?? 'default.png'))); ?>" alt="Profile" class="img-fluid">
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <div>
                                            <p class="m-0 small"><span class="badge rounded-pill bg-primary-subtle text-primary small"><?php echo e($item->programStudi->nama); ?></span></p>
                                            <p class="fw-bold small font-size-14 m-0"><?php echo e($item->name); ?></p>    
                                            <p class="m-0 small"><strong>NIDN.</strong> <?php echo e($item->nidn); ?> | <strong>NIP/NIK/NIPPPK.</strong> <?php echo e($item->nip); ?></p>    
                                            <p class="m-0 small"><strong>Email.</strong> <?php echo e($item->email); ?> | <strong>Nomor.</strong> <?php echo e($item->telp); ?></p>
                                            <p class="m-0 small"><strong>Bidang Keahlian :</strong> <?php echo e($item->bidang_keahlian); ?></p>    
                                        </div>
                                    </div>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('administrator.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Sistem-Monitoring-TA\resources\views/administrator/profile-dosen/index.blade.php ENDPATH**/ ?>