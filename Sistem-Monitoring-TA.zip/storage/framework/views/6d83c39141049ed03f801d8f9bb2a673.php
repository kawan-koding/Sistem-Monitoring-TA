

<?php $__env->startSection('content'); ?>
<style>
     .card {
        position: relative;
        overflow: hidden;
    }

    .card-icon {
        position: absolute;
        top: 0;
        right: -2%;
        transform: translateY(-50%);
        font-size: 5rem;
        opacity: 0.3;
        transform: rotate(25deg);
    }

    .date-area {
        width: 100%;
        overflow: hidden;
        display: flex;
        justify-content: start;
    }

    .date-area-scroll {
        display: flex;
        cursor: grab;
    }

    .date-item {
        display: block;
        padding: 1.2rem 3.5rem;
        user-select: none;
        white-space: nowrap;
        text-align: center;
        font-size: 0.8rem;
        line-height: 15 px;
    }

    /* shadow-bottom inner if actived */
    .date-item.active {
        color: #2d3cc7 !important;
        font-weight: bold;
        box-shadow: 0px 5px 10px #13209660 inset;
    }

    #schedule-content::-webkit-scrollbar {
        width: 5px;
    }

    #schedule-content::-webkit-scrollbar-track {
        background: #f1f1f1;
    }

    #schedule-content::-webkit-scrollbar-thumb {
        background: #c2c1c1;
    }

    #schedule-content::-webkit-scrollbar-thumb:hover {
        background: #a0a0a0;
    }

    .chevron-button {
        cursor: pointer;
    }

</style>

<?php if(session('switchRoles') == 'Admin'): ?>
    <?php echo $__env->make('administrator.dashboard.partials.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php elseif(session('switchRoles') == 'Mahasiswa'): ?>
    <?php echo $__env->make('administrator.dashboard.partials.mahasiswa', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php elseif(session('switchRoles') == 'Dosen'): ?>
    <?php echo $__env->make('administrator.dashboard.partials.dosen', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php elseif(session('switchRoles') == 'Kaprodi'): ?>
    <?php echo $__env->make('administrator.dashboard.partials.kaprodi', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>


<div class="card shadow-sm mb-3">
    <div class="d-flex border-bottom">
        <div class="px-4 d-flex align-items-center border chevron-button" data-direction="left"><i class="fa fa-chevron-left"></i></div>
        <div class="date-area" data-role="resizable-container">
            <div class="date-area-scroll" data-role="resizable-item">
                <?php for($year = 2024; $year <= 2025; $year++): ?>
                    <?php for($month = 1; $month <= 12; $month++): ?>
                        <?php for($i = 1; $i <= date('t', mktime(0, 0, 0, $month, 1, $year)); $i++): ?>
                            <div class="date-item <?php echo e(date('d-m-Y', mktime(0, 0, 0, $month, $i, $year)) == date('d-m-Y') ? 'active' : ''); ?>"
                                data-value="<?php echo e(date('Y-m-d', mktime(0, 0, 0, $month, $i, $year))); ?>">
                                <h4 class="m-0"><?php echo e(\Carbon\Carbon::parse(date('Y-m-d', mktime(0, 0, 0, $month, $i, $year)))->locale('id')->translatedFormat('D')); ?> <?php echo e(str_pad($i, 2, '0', STR_PAD_LEFT)); ?></h4>
                                <span
                                    class="text-muted small"><?php echo e(\Carbon\Carbon::parse(date('Y-m-d', mktime(0, 0, 0, $month, $i, $year)))->locale('id')->translatedFormat('F Y')); ?></span>
                            </div>
                        <?php endfor; ?>
                    <?php endfor; ?>
                <?php endfor; ?>
            </div>
        </div>
        <div class="px-4 d-flex align-items-center border chevron-button" data-direction="right"><i class="fa fa-chevron-right"></i></div>
    </div>
    <div class="card-body">
        <div class="col-md-10 col-sm-12 col-12 mb-3 mx-auto mt-2 mb-4">
            <div class="row justify-content-between align-items-center">
                
                    <div class="col-md-8 col-sm-10 mx-auto">
                        <div class="input-group">
                            <input type="text" class="form-control" placeholder="Search..." autocomplete="off" data-role="schedule-search">
                            <span class="input-group-text"><i class="fa fa-search"></i></span>
                        </div>
                    </div>
                
            </div>
        </div>
        
        
        <div id="schedule-content" style="min-height: 400px;max-height: 75vh;overflow-y: auto">
            <div class="d-flex align-items-center justify-content-center py-5">
                <div class="text-center py-5">
                    <img src="<?php echo e(asset('assets/images/no-data.png')); ?>" height="350" alt="">
                    <p class="text-muted m-0">Tidak ada jadwal yang ditemukan.</p>
                </div>
            </div>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('administrator.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Sistem-Monitoring-TA\resources\views/administrator/dashboard/index.blade.php ENDPATH**/ ?>