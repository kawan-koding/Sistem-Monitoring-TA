
<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12 col-sm-12 col-g-12">
        <div class="card">
            <div class="card-body">
                <?php if(in_array(session('switchRoles'), ['Admin','Developer','Kajur','Kaprodi'])): ?>
                <div class="d-flex flex-column flex-md-row justify-content-between align-items-md-center gap-2">
                    <?php if(in_array(session('switchRoles'), ['Admin','Developer'])): ?>
                    <div class="btn-group" role="group">
                        <button id="btnGroupVerticalDrop1" type="button" class="btn btn-primary dropdown-toggle mb-2" style="max-width: 150px;" data-bs-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            <i class="fa fa-file-excel me-2"></i> Export Data <i class="mdi mdi-chevron-down"></i>
                        </button>
                        <div class="dropdown-menu" aria-labelledby="btnGroupVerticalDrop1">
                            <?php $__currentLoopData = $prodi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a class="dropdown-item" target="_blank" href="<?php echo e(route('apps.daftar-ta.export', ['prodi' => $item->id])); ?>"><?php echo e($item->display); ?></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <?php endif; ?>
                    <form action="" >
                        <div class="d-flex gap-2 flex-column flex-md-row">
                            <?php if(in_array(session('switchRoles'), ['Admin','Developer'])): ?>
                            <select name="program_studi" id="program_studi" class="form-control" onchange="this.form.submit()">
                                <option selected disabled hidden>Filter Program Studi</option>
                                <option value="semua" <?php echo e(request('program_studi') == 'semua' ? 'selected' : ''); ?>>Semua Program Studi</option>
                                <?php $__currentLoopData = $prodi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($p->id); ?>" <?php echo e(request('program_studi') == $p->id ? 'selected' : ''); ?>><?php echo e($p->nama); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php endif; ?>
                            <select name="mahasiswa" id="mahasiswa" class="form-control" onchange="this.form.submit()">
                                <option selected disabled hidden>Filter Mahasiswa</option>
                                <option value="semua" <?php echo e(request('mahasiswa') == 'semua' ? 'selected' : ''); ?>>Semua</option>
                                <option value="tanpa_ta" <?php echo e(request('mahasiswa') == 'tanpa_ta' ? 'selected' : ''); ?>>Belum Mengajukan TA</option>
                                <option value="belum_sempro" <?php echo e(request('mahasiswa') == 'belum_sempro' ? 'selected' : ''); ?>>Belum Sempro</option>
                                <option value="belum_sidang" <?php echo e(request('mahasiswa') == 'belum_sidang' ? 'selected' : ''); ?>>Belum Sidang</option>
                                <option value="belum_pemberkasan" <?php echo e(request('mahasiswa') == 'belum_pemberkasan' ? 'selected' : ''); ?>>Belum Pemberkasan Akhir</option>
                            </select>
                            <select name="filter" id="" class="form-control" onchange="this.form.submit()">
                                <option selected disabled hidden>Filter Jenis Penyelesaian</option>
                                <option value="semua" <?php echo e(request('filter') == 'semua'  ? 'selected' : ''); ?>>Semua</option>
                                <option value="I" <?php echo e($filter == 'I' ? 'selected' : ''); ?>>Individu</option>
                                <option value="K" <?php echo e($filter == 'K' ? 'selected' : ''); ?>>Kelompok</option>
                            </select>
                        </div>
                    </form>
                </div>
                <hr>
                <?php endif; ?>
                
                <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <i class="mdi mdi-check-all me-2"></i> <?php echo e(session('success')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
                        </button>
                    </div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <i class="mdi mdi-block-helper me-2"></i><?php echo e(session('error')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
                        </button>
                    </div>
                <?php endif; ?>
                <?php if($errors->any()): ?>
                    <div class="alert alert-error alert-danger alert-dismissible fade show" role="alert">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
                        </button>
                    </div>
                <?php endif; ?>
                <div class="table-responsive">
                    <table class="table table-striped" id="datatable">
                        <thead>
                            <tr>
                                <th width="5%">No</th>
                                <th width="20%">Mahasiswa</th>
                                <th width="40%">Judul</th>
                                <th width="20%">Dosen</th>
                                <th width="10%">Periode</th>
                                <th width="10%">Status</th>
                                <th>Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($loop->iteration); ?></td>
                                    <td>
                                        <p class="m-0 badge rounded-pill bg-primary-subtle text-primary small"><?php echo e($item->programStudi->display); ?></p> 
                                        <a href="#" class="m-0" data-bs-toggle="modal" data-bs-target="#mahasiswaModal<?php echo e($key); ?>"> 
                                            <p class="fw-bold m-0"><?php echo e($item->nama_mhs); ?></p>
                                        </a>
                                        <div class="modal fade" id="mahasiswaModal<?php echo e($key); ?>" tabindex="-1" aria-labelledby="mahasiswaModalLabel<?php echo e($key); ?>" aria-hidden="true">
                                            <div class="modal-dialog modal-lg modal-dialog-centered">
                                                <div class="modal-content">
                                                    <div class="modal-header">
                                                        <h5 class="modal-title" id="mahasiswaModalLabel<?php echo e($key); ?>">Biodata Mahasiswa</h5>
                                                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                                    </div>
                                                    <div class="modal-body">
                                                        <div class="row">
                                                            <div class="col-md-4 text-center">
                                                                <img src="<?php echo e($item->user->image == null ? 'https://ui-avatars.com/api/?background=random&name=' . $item->mahasiswa->name : asset('storage/images/users/' . $item->user->image)); ?>"
                                                                    alt="Foto Mahasiswa" class="img-fluid rounded">
                                                            </div>
                                                            <div class="col-md-8">
                                                                <table class="table table-sm table-borderless">
                                                                    <tr>
                                                                        <th>Nama</th>
                                                                        <td><?php echo e($item->nama_mhs ?? '-'); ?>

                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <th>NIM</th>
                                                                        <td><?php echo e($item->nim ?? '-'); ?>

                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <th>Kelas</th>
                                                                        <td><?php echo e($item->kelas ?? '-'); ?>

                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <th>Prodi</th>
                                                                        <td><?php echo e($item->programStudi->display ?? '-'); ?>

                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <th>Telepon</th>
                                                                        <td><?php echo e($item->telp ?? '-'); ?>

                                                                        </td>
                                                                    </tr>
                                                                    <tr>
                                                                        <th>Email</th>
                                                                        <td><?php echo e($item->email ?? '-'); ?>

                                                                        </td>
                                                                    </tr>
                                                                </table>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        <p class="m-0 p-0 text-muted small">NIM : <?php echo e($item->nim); ?></p>
                                    </td>
                                    <td>
                                        <span class="badge badge-soft-primary small mb-1 fw-bold"><?php echo e(isset($item->tugas_akhir->first()->tipe) ? ($item->tugas_akhir->first()->tipe == 'I' ? 'Individu' : 'Kelompok') : '-'); ?></span>
                                        <p class="m-0 small"><strong><?php echo e($item->tugas_akhir->first()->judul ?? '-'); ?></strong></p>
                                        <p class="m-0 text-muted font-size-15 small"><?php echo e($item->tugas_akhir->first()->topik->nama_topik ?? '-'); ?> - <?php echo e($item->tugas_akhir->first()->jenis_ta->nama_jenis ?? '-'); ?></p>
                                    </td>
                                    <td>
                                        <p class="fw-bold small m-0">Pembimbing</p>
                                        <ol>
                                            <?php if(isset($item->tugas_akhir) && isset($item->tugas_akhir->first()->bimbing_uji)): ?>
                                                <?php $__currentLoopData = $item->tugas_akhir->first()->bimbing_uji->where('jenis', 'pembimbing')->sortBy('urut'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pembimbing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li class="small"><?php echo e($pembimbing->dosen->name); ?></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                                <li class="small">-</li>
                                            <?php endif; ?>
                                        </ol>
                                        <p class="fw-bold small m-0">Penguji</p>
                                        <ol>
                                            <?php if(isset($item->tugas_akhir) && isset($item->tugas_akhir->first()->bimbing_uji)): ?>
                                                <?php $__currentLoopData = $item->tugas_akhir->first()->bimbing_uji->where('jenis', 'penguji')->sortBy('urut'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $penguji): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <li class="small"><?php echo e($penguji->dosen->name); ?></li>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php else: ?>
                                                <li class="small">-</li>
                                            <?php endif; ?>

                                        </ol>
                                    </td>
                                    <td><p class="small"><?php echo e($item->tugas_akhir->first()->periode_ta->nama ?? '-'); ?></p></td>
                                    <td>
                                        <span class="badge <?php echo e(isset($item->tugas_akhir->first()->status) ? ($item->tugas_akhir->first()->status == 'acc' ? 'badge-soft-success' : (in_array($item->tugas_akhir->first()->status, ['draft', 'pengajuan ulang']) ? 'bg-dark-subtle text-body' : ($item->tugas_akhir->first()->status == 'revisi' ? 'badge-soft-warning' : 'badge-soft-danger'))) : ''); ?> small mb-1"> <?php echo e(ucfirst($item->tugas_akhir->first()->status ?? '-')); ?> </span>
                                    </td>
                                    <td>
                                        <?php if(isset($item->tugas_akhir) && isset($item->tugas_akhir->first()->id)): ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update-daftar-ta')): ?>
                                            <a href="<?php echo e(route('apps.daftar-ta.edit', $item->tugas_akhir->first()->id)); ?>" class="btn btn-sm btn-outline-primary mb-1" title="Edit"><i class="bx bx-edit-alt"></i></a>
                                            <?php endif; ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('read-daftar-ta')): ?>
                                            <a href="<?php echo e(route('apps.daftar-ta.show', $item->tugas_akhir->first()->id)); ?>" class="btn btn-sm btn-outline-warning mb-1" title="Detail"><i class="bx bx-show"></i></a>
                                            <?php endif; ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-daftar-ta')): ?>
                                            <button onclick="hapusDaftarTa('<?php echo e($item->tugas_akhir->first()->id); ?>', '<?php echo e(route('apps.daftar-ta.delete', $item->tugas_akhir->first()->id)); ?>')" class="btn btn-sm btn-outline-dark mb-3" title="Hapus"><i class="bx bx-trash"></i></button>
                                            <?php endif; ?>
                                        <?php else: ?> 
                                            -
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('administrator.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Sistem-Monitoring-TA\resources\views/administrator/daftar-ta/index.blade.php ENDPATH**/ ?>