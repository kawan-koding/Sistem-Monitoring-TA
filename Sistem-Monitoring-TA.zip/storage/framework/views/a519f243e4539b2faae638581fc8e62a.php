<!-- sample modal content -->
<div id="modalDaftarSidang<?php echo e($item->id); ?>" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="daftarSidangLabel"
    aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title mt-0" id="daftarSidangLabel<?php echo e($item->id); ?>"></h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="" id="daftarSidangAction<?php echo e($item->id); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <?php if($item->status == 'belum_daftar' || $item->status == 'sudah_daftar'): ?>
                        <?php $__currentLoopData = $document_sidang->where('jenis', 'pra_sidang'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $document = $doc
                                    ->pemberkasan()
                                    ->where('tugas_akhir_id', $item->tugas_akhir->id)
                                    ->first();
                            ?>
                            <div class="d-flex align-items-center gap-2 mb-3 " id="document<?php echo e($doc->id); ?>">
                                <?php if($document): ?>
                                    <i class="file-icon bx bx-check-circle text-success"></i>
                                <?php else: ?>
                                    <i class="file-icon mdi mdi-close-circle-outline text-danger"></i>
                                <?php endif; ?>
                                <div class="w-100 fw-bold text-start">
                                    <?php echo e(ucwords(strtolower($doc->nama))); ?>

                                    <?php if($document): ?>
                                        <p class="file-desc text-muted small m-0 p-0"><a
                                                href="<?php echo e(asset('storage/files/pemberkasan/' . $document->filename)); ?>"
                                                target="_blank">Lihat berkas</a></p>
                                    <?php else: ?>
                                        <p class="file-desc text-muted small m-0 p-0"><i class="text-danger">*</i>)
                                            Belum ada berkas</p>
                                    <?php endif; ?>
                                </div>
                                <label for="file<?php echo e($doc->id); ?>">
                                    <input type="file" id="file<?php echo e($doc->id); ?>"
                                        onchange="changeFile('#document<?php echo e($doc->id); ?>')"
                                        name="document_<?php echo e($doc->id); ?>" class="d-none" accept="<?php echo e($doc->tipe_dokumen == 'pdf' ? '.pdf' : 'image/*'); ?>">
                                    <?php if($document): ?>
                                        <div class="file-btn btn btn-outline-primary btn-sm">Perbarui</div>
                                    <?php else: ?>
                                        <div class="file-btn btn btn-outline-primary btn-sm">Unggah</div>
                                    <?php endif; ?>
                                </label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <?php $__currentLoopData = $document_sidang->whereIn('jenis', ['pra_sidang', 'sidang']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $document = $doc
                                    ->pemberkasan()
                                    ->where('tugas_akhir_id', $item->tugas_akhir->id)
                                    ->first();
                            ?>
                            <div class="d-flex align-items-center gap-2 mb-3 " id="document<?php echo e($doc->id); ?>">
                                <?php if($document): ?>
                                    <i class="file-icon bx bx-check-circle text-success"></i>
                                <?php else: ?>
                                    <i class="file-icon mdi mdi-close-circle-outline text-danger"></i>
                                <?php endif; ?>
                                <div class="w-100 fw-bold text-start">
                                    <?php echo e(ucwords(strtolower($doc->nama))); ?>

                                    <?php if($document): ?>
                                        <p class="file-desc text-muted small m-0 p-0"><a
                                                href="<?php echo e(asset('storage/files/pemberkasan/' . $document->filename)); ?>"
                                                target="_blank">Lihat berkas</a></p>
                                    <?php else: ?>
                                        <p class="file-desc text-muted small m-0 p-0"><i class="text-danger">*</i>)
                                            Belum ada berkas</p>
                                    <?php endif; ?>
                                </div>
                                <label for="file<?php echo e($doc->id); ?>">
                                    <input type="file" id="file<?php echo e($doc->id); ?>"
                                        onchange="changeFile('#document<?php echo e($doc->id); ?>')"
                                        name="document_<?php echo e($doc->id); ?>" class="d-none" accept="<?php echo e($doc->tipe_dokumen == 'pdf' ? '.pdf' : 'image/*'); ?>">
                                    <?php if($document): ?>
                                        <div class="file-btn btn btn-outline-primary btn-sm">Perbarui</div>
                                    <?php else: ?>
                                        <div class="file-btn btn btn-outline-primary btn-sm">Unggah</div>
                                    <?php endif; ?>
                                </label>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary waves-effect" data-bs-dismiss="modal">Batal</button>
                    <button type="submit" class="btn btn-primary waves-effect waves-light">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div id="modalValidasiFile<?php echo e($item->id); ?>" class="modal fade" tabindex="-1" role="dialog"
    aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="" id="validasiFileAction<?php echo e($item->id); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="modal-header">
                    <?php if($item->status == 'sudah_daftar'): ?>
                        <h5 class="modal-title mt-0">Validasi Berkas Pendaftaran Sidang</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    <?php else: ?>
                        <h5 class="modal-title mt-0">Validasi Berkas Sidang</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    <?php endif; ?>
                </div>
                <div class="modal-body">
                    <?php if($item->status == 'belum_daftar' || $item->status == 'sudah_daftar'): ?>
                    <div class="row">
                        <?php $__currentLoopData = $document_sidang->where('jenis', 'pra_sidang'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $document = $doc
                                    ->pemberkasan()
                                    ->where('tugas_akhir_id', $item->tugas_akhir->id)
                                    ->first();
                            ?>
                            <div class="col-md-4 col-sm-6 col-12 border p-3" style="position: relative">
                                <div class="d-block text-center fw-bold" style="height: calc(100% - 115px);">
                                    <?php echo e(ucwords(strtolower($doc->nama))); ?></div>
                                <div class="d-flex align-items-center justify-content-center my-3" style="height: 50px">
                                    <?php if($document): ?>
                                        <i class="fa fa-file-pdf text-danger fa-3x"></i>
                                    <?php endif; ?>
                                </div>
                                <div class="text-center">
                                    <?php if($document): ?>
                                        <a href="<?php echo e(asset('storage/files/pemberkasan/' . $document->filename)); ?>"
                                            class="btn btn-secondary btn-sm" target="_blank">Lihat Berkas</a>
                                    <?php else: ?>
                                        <i class="text-danger">*</i>) Belum ada berkas
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php else: ?>
                    <div class="row">
                        <?php $__currentLoopData = $document_sidang->whereIn('jenis', ['pra_sidang', 'sidang']); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $document = $doc
                                ->pemberkasan()
                                ->where('tugas_akhir_id', $item->tugas_akhir->id)
                                ->first();
                            ?>
                            <div class="col-md-4 col-sm-6 col-12 border p-3" style="position: relative">
                                <div class="d-block text-center fw-bold" style="height: calc(100% - 115px);">
                                    <?php echo e(ucwords(strtolower($doc->nama))); ?></div>
                                <div class="d-flex align-items-center justify-content-center my-3" style="height: 50px">
                                    <?php if($document): ?>
                                        <i class="fa fa-file-pdf text-danger fa-3x"></i>
                                    <?php endif; ?>
                                </div>
                                <div class="text-center">
                                    <?php if($document): ?>
                                        <a href="<?php echo e(asset('storage/files/pemberkasan/' . $document->filename)); ?>"
                                            class="btn btn-secondary btn-sm" target="_blank">Lihat Berkas</a>
                                    <?php else: ?>
                                        <i class="text-danger">*</i>) Belum ada berkas
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <?php endif; ?>
                </div>
                <?php if($item->status == 'sudah_terjadwal' || $item->status == 'sudah_sidang'): ?>
                    <div class="modal-footer">
                        <button class="btn btn-outline-success waves-effect"> <i class="fa fa-check-circle"></i> Berkas Lengkap</button>
                    </div>
                <?php endif; ?>
            </form>
        </div>
    </div>
</div>

<div class="modal fade" id="myModal<?php echo e($item->id); ?>">
    <div class="modal-dialog text-start">
        <div class="modal-content">
            <form action="<?php echo e(route('apps.jadwal-sidang.update-status', $item->tugas_akhir->sidang->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-header d-block">
                    <h5 class="mb-0">Update status sidang akhir</h5>
                    <p class="text-muted small mb-0">Berikan keputusan terkait status sidang akhir</p>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="">Status Sidang Akhir <span class="text-danger">*</span></label><br>
                        <label for="acc<?php echo e($item->id); ?>" class="me-2"><input type="radio" name="status" id="acc<?php echo e($item->id); ?>" value="acc" <?php echo e($item->tugas_akhir->status_sidang == 'acc' ? 'checked' : ''); ?>> Setujui</label>
                        <label for="revisi<?php echo e($item->id); ?>" class="me-2"><input type="radio" name="status" id="revisi<?php echo e($item->id); ?>" value="revisi" <?php echo e($item->tugas_akhir->status_sidang == 'revisi' ? 'checked' : ''); ?>> Disetujui dengan revisi</label>
                        <label for="retrial<?php echo e($item->id); ?>" class="me-2"><input type="radio" name="status" id="retrial<?php echo e($item->id); ?>" value="retrial" <?php echo e($item->tugas_akhir->status_sidang == 'retrial' ? 'checked' : ''); ?>> Sidang Ulang</label>
                    </div>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-light" type="button" data-bs-dismiss="modal">Batal</button>
                    <button class="btn btn-primary" type="submit"><i class="bx bx-save"></i> Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php /**PATH C:\laragon\www\Sistem-Monitoring-TA\resources\views/administrator/jadwal-sidang/partials/modal.blade.php ENDPATH**/ ?>