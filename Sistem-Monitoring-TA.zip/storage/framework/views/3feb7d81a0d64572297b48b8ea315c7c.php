<?php $__env->startSection('content'); ?>

<div class="row">
    <div class="col-md-12 col-sm-12 col-g-12">
        <div class="card">
            <div class="card-body">

                <?php if(session('switchRoles') !== 'Kajur'): ?>
                <button onclick="tambahData()" class="btn btn-primary"><i class="fa fa-plus"></i> Tambah</button>
                <button onclick="importData()" class="btn btn-success"><i class="fa fa-file-excel"></i> Import</button>
                
                <hr>
                <?php endif; ?>
                <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <i class="mdi mdi-check-all me-2"></i> <?php echo e(session('success')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
                        </button>
                    </div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                        <i class="mdi mdi-block-helper me-2"></i><?php echo e(session('error')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
                        </button>
                    </div>
                <?php endif; ?>
                <?php if($errors->any()): ?>
                <div class="alert alert-error alert-danger alert-dismissible fade show" role="alert">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
                    </button>
                </div>
                <?php endif; ?>
                <div class="table-responsive">
                    <table class="table table-striped" id="datatable">
                        <thead>
                            <tr>
                                <th width="5%">No</th>
                                <th width="40%">Nama</th>
                                <th>Email</th>
                                <th>Jenis Kelamin</th>
                                <th>Program Studi</th>
                                <th>Bidang Keahlian</th>
                                <?php if(session('switchRoles') !== 'Kajur'): ?>
                                <th>Aksi</th>
                                <?php endif; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $dataDosen; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($loop->iteration); ?></td>
                                <td>
                                    <div class="d-flex align-items-center">
                                        <div class="">
                                            <strong><?php echo e(ucfirst($item->name)); ?></strong>
                                            <p class="m-0 p-0 text-muted small">NIDN : <?php echo e($item->nidn); ?></p>
                                            <p class="m-0 p-0 text-muted small">NIP/NIPPPK/NIK: <?php echo e($item->nip); ?></p>
                                        </div>
                                    </div>
                                </td>
                                <td>
                                    <div class="d-fex align-items-center">
                                        <div class="">
                                            <strong><?php echo e(ucfirst($item->email)); ?></strong>
                                            <p class="m-0 p-0 text-muted small"><?php echo e($item->telp); ?></p>
                                        </div>
                                    </div>
                                </td>
                                <td><?php echo e($item->jenis_kelamin == 'L' ? 'Laki-laki' : ($item->jenis_kelamin == 'P' ? 'Perempuan' : '-')); ?></td>
                                <td class="text-center"><?php echo e($item->programStudi->nama ?? '-'); ?></td>
                                <td class="text-center"><?php echo e($item->bidang_keahlian ??  '-'); ?></td>
                                <?php if(session('switchRoles') !== 'Kajur'): ?>
                                <td class="text-center">
                                    <button onclick="editData('<?php echo e($item->id); ?>', '<?php echo e(route('apps.dosen.show', $item->id)); ?>')" class="btn btn-outline-primary btn-sm"><i class="bx bx-edit-alt"></i></a>
                                    <button class="btn btn-outline-dark btn-sm mx-1 my-1" onclick="hapusDosen('<?php echo e($item->id); ?>', '<?php echo e(route('apps.dosen.delete', $item->id)); ?>')"><i class="bx bx-trash"></i></button>
                                </td>
                                <?php endif; ?>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php echo $__env->make('administrator.dosen.partials.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('administrator.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Sistem-Monitoring-TA\resources\views/administrator/dosen/index.blade.php ENDPATH**/ ?>