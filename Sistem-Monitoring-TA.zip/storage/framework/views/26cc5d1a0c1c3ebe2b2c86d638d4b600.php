<div class="vertical-menu">
    <div class="h-100">
        <div class="user-wid text-center py-4">
            <div class="user-img">
                <img src="<?php echo e(asset('storage/images/users/'. getInfoLogin()->image)); ?>" alt="" class="avatar-md mx-auto rounded-circle">
            </div>

            <div class="mt-3">

                <a href="#" class="text-reset fw-medium font-size-16"><?php echo e(ucfirst(getInfoLogin()->name)); ?></a>
                <p class="text-muted mt-1 mb-0 font-size-13 mb-2"><?php echo e(ucfirst(session('switchRoles'))); ?>

                    <?php if(session('switchRoles') === 'Kaprodi' && session('program_studi')): ?>
                        <?php echo e(session('program_studi')); ?>

                    <?php endif; ?>
                </p>
                <div class="dropdown dropend">
                    
                        <button class="btn btn-primary btn-sm dropdown-toggle" type="button" id="dropdownMenuButton" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-user-lock"></i>
                        </button>
                    
                    <ul class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                        <?php $__currentLoopData = getAvailableRoles(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if(userHasRole($role)): ?>
                                <li>
                                    <a class="dropdown-item" href="<?php echo e(route('apps.switcher', ['role' => $role])); ?>"><?php echo e(ucfirst($role)); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                  </div>

            </div>
        </div>

        <!--- Sidemenu -->
        <div id="sidebar-menu">
            <!-- Left Menu Start -->
            <ul class="metismenu list-unstyled" id="side-menu">
                <li class="menu-title">Menu</li>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(['read-dashboard'])): ?>
                <li>
                    <a href="<?php echo e(route('apps.dashboard')); ?>" class=" waves-effect">
                        <i class="mdi mdi-airplay"></i>
                        <span>Dashboard</span>
                    </a>
                </li>
                <?php endif; ?>
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(['read-rekomendasi-topik'])): ?>
                <li>
                    <a href="<?php echo e(route('apps.rekomendasi-topik')); ?>" class=" waves-effect">
                        <i class="mdi mdi-book-open"></i>
                        <span>Tawaran Tugas Akhir</span>
                    </a>
                </li>
                <?php endif; ?>
                <?php if(session('switchRoles') === 'Dosen'): ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(['read-daftar-bimbingan'])): ?>
                    <li>
                        <a href="<?php echo e(route('apps.daftar-bimbingan')); ?>" class=" waves-effect">
                            <i class="mdi mdi-file-edit-outline"></i>
                            <span>Daftar Bimbingan</span>
                        </a>
                    </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(['read-jadwal-seminar'])): ?>
                    <li>
                        <a href="<?php echo e(route('apps.jadwal')); ?>" class=" waves-effect">
                            <i class="bx bx-calendar"></i>
                            <span>Jadwal Seminar</span>
                        </a>
                    </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(['read-daftar-sidang'])): ?>
                    <li>
                        <a href="<?php echo e(route('apps.jadwal-sidang')); ?>" class=" waves-effect">
                            <i class="bx bx-calendar-event"></i>
                            <span>Jadwal Sidang</span>
                        </a>
                    </li>
                    <?php endif; ?>
                <?php endif; ?>

                <?php if(in_array(session('switchRoles'), ['Mahasiswa','Developer'])): ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(['read-pengajuan-tugas-akhir'])): ?>
                    <li>
                        <a href="<?php echo e(route('apps.pengajuan-ta')); ?>" class=" waves-effect">
                            <i class="mdi mdi-calendar-text"></i>
                            <span>Tugas akhir</span>
                        </a>
                    </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(['read-jadwal-seminar'])): ?>
                    <li>
                        <a href="<?php echo e(route('apps.jadwal-seminar')); ?>" class=" waves-effect">
                            <i class="bx bx-calendar"></i>
                            <span>Jadwal Seminar</span>
                        </a>
                    </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(['read-daftar-sidang'])): ?>
                    <li>
                        <a href="<?php echo e(route('apps.jadwal-sidang')); ?>" class=" waves-effect">
                            <i class="bx bx-calendar-event"></i>
                            <span>Jadwal Sidang</span>
                        </a>
                    </li>
                    <?php endif; ?>
                <?php endif; ?>

                <?php if(in_array(session('switchRoles'), ['Mahasiswa','Kaprodi','Kajur'])): ?>
                <li>
                    <a href="<?php echo e(route('apps.profile-dosen')); ?>" class=" waves-effect">
                        <i class="mdi mdi-account-details"></i>
                        <span>Pofile Dosen</span>
                    </a>
                </li>
                <?php endif; ?>

                <?php if(in_array(session('switchRoles'), ['Admin','Developer','Kajur','Kaprodi','Teknisi'])): ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['read-mahasiswa', 'read-dosen', 'read-ruangan', 'read-topik', 'read-topik', 'read-jurusan', 'read-program-studi', 'read-jenis', 'read-kuota', 'read-kategori-nilai', 'read-jenis-dokumen'])): ?>
                    <li>
                        <a href="javascript: void(0);" class="has-arrow waves-effect">
                            <i class="mdi mdi-inbox-full"></i>
                            <span>Master Data</span>
                        </a>
                        <ul class="sub-menu" aria-expanded="false">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(['read-jurusan'])): ?>
                            <li><a href="<?php echo e(route('apps.jurusan')); ?>">Jurusan</a></li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(['read-program-studi'])): ?>
                            <li><a href="<?php echo e(route('apps.program-studi')); ?>">Program Studi</a></li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(['read-mahasiswa'])): ?>
                            <li><a href="<?php echo e(route('apps.mahasiswa')); ?>">Mahasiswa</a></li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(['read-dosen'])): ?>
                            <li><a href="<?php echo e(route('apps.dosen')); ?>">Dosen</a></li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(['read-topik'])): ?>
                            <li><a href="<?php echo e(route('apps.topik')); ?>">Topik</a></li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(['read-ruangan'])): ?>
                            <li><a href="<?php echo e(route('apps.ruangan')); ?>">Ruangan</a></li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(['read-jenis'])): ?>
                            <li><a href="<?php echo e(route('apps.jenis-ta')); ?>">Jenis TA</a></li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(['read-kuota'])): ?>
                            <li><a href="<?php echo e(route('apps.kuota-dosen')); ?>">Kuota Dosen</a></li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(['read-kategori-nilai'])): ?>
                            <li><a href="<?php echo e(route('apps.kategori-nilai')); ?>">Kategori Nilai</a></li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(['read-jenis-dokumen'])): ?>
                            <li><a href="<?php echo e(route('apps.jenis-dokumen')); ?>">Jenis Dokumen</a></li>
                            <?php endif; ?>
                        </ul>
                    </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(['read-periode'])): ?>
                        <li>
                            <a href="<?php echo e(route('apps.periode')); ?>" class=" waves-effect">
                                <i class="mdi mdi-calendar-text"></i>
                                <span>Periode TA</span>
                            </a>
                        </li>
                    <?php endif; ?>
                <?php endif; ?>

                <?php if(in_array(session('switchRoles'), ['Admin','Kaprodi','Developer','Kajur'])): ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['read-daftar-ta', 'read-pengajuan-tugas-akhir', 'read-pembagian-dosen'])): ?>
                        <li>
                            <a href="javascript: void(0);" class="has-arrow waves-effect">
                                <i class="mdi mdi-clipboard-list-outline"></i>
                                <span>Tugas Akhir</span>
                            </a>
                            <ul class="sub-menu" aria-expanded="false">
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(['read-daftar-ta'])): ?>
                                <li><a href="<?php echo e(route('apps.daftar-ta')); ?>">Daftar TA</a></li>
                                <?php endif; ?>
                                <?php if(getInfoLogin()->hasRole('Kaprodi') || getInfoLogin()->hasRole('Developer')): ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(['read-pengajuan-tugas-akhir'])): ?>
                                    <li><a href="<?php echo e(route('apps.pengajuan-ta')); ?>">Pengajuan TA</a></li>
                                    <?php endif; ?>
                                <?php endif; ?>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(['read-pembagian-dosen'])): ?>
                                <li><a href="<?php echo e(route('apps.pembagian-dosen')); ?>">Pembagian Dosen</a></li>
                                <?php endif; ?>
                                <?php if((getInfoLogin()->hasRole('Admin') && (session('switchRoles') == 'Admin') || getInfoLogin()->hasRole('Mahasiswa'))): ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('read-jadwal-seminar')): ?>
                                    <li><a href="<?php echo e(route('apps.jadwal-seminar')); ?>">Jadwal Seminar</a></li>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('read-jadwal-seminar')): ?>
                                    <li><a href="<?php echo e(route('apps.jadwal-sidang')); ?>">Jadwal Sidang</a></li>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </ul>
                        </li>
                    <?php endif; ?>
                <?php endif; ?>

                <?php if(in_array(session('switchRoles'), ['Admin','Developer','Teknisi'])): ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['read-users', 'read-roles'])): ?>
                        <li>
                        <a href="javascript: void(0);" class="has-arrow waves-effect">
                            <i class="mdi mdi-account-circle-outline"></i>
                            <span>Manajemen Pengguna</span>
                        </a>
                        <ul class="sub-menu" aria-expanded="false">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(['read-users'])): ?>
                            <li><a href="<?php echo e(route('apps.users')); ?>">Pengguna</a></li>
                            <?php endif; ?>
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(['read-roles'])): ?>
                            <li><a href="<?php echo e(route('apps.roles')); ?>">Role</a></li>
                            <?php endif; ?>
                        </ul>
                    </li>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['read-kuota', 'read-settings'])): ?>
                    <li>
                        <a href="javascript: void(0);" class="has-arrow waves-effect">
                            <i class="mdi mdi-settings"></i>
                            <span>Pengaturan</span>
                        </a>
                        <ul class="sub-menu" aria-expanded="false">
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check(['read-setting'])): ?>
                            <li><a href="<?php echo e(route('apps.settings')); ?>">Aplikasi</a></li>
                            <?php endif; ?>
                        </ul>
                    </li>
                    <?php endif; ?>
                <?php endif; ?>
                <?php if(session('switchRoles') == 'Admin' || session('switchRoles') == 'Developer'): ?>
                <li>
                    <a href="<?php echo e(route('apps.archives')); ?>" class=" waves-effect">
                        <i class="mdi mdi-archive"></i>
                        <span>Arsip</span>
                    </a>
                </li>
                <?php endif; ?>
                <li>
                    <a href="<?php echo e(route('apps.guide')); ?>" class=" waves-effect">
                        <i class="mdi mdi-television-guide"></i>
                        <span>Panduan</span>
                    </a>
                </li>
            </ul>
        </div>
        <!-- Sidebar -->
    </div>
</div>
<!-- Left Sidebar End -->

<?php /**PATH C:\laragon\www\Sistem-Monitoring-TA\resources\views/administrator/layout/partials/side-nav.blade.php ENDPATH**/ ?>