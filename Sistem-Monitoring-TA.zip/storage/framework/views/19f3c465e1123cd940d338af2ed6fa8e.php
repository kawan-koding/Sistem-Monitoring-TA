<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <link rel="shortcut icon" href="<?php echo e(asset('storage/images/settings/' . (getSetting('app_favicon') ?? 'poliwangi.png'))); ?>">
    <title> <?php echo e($title ?? 'unknown'); ?> | Administrator <?php echo e(getSetting('app_name')); ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <!-- DataTables -->
    <link href="<?php echo e(asset('assets/libs/datatables.net-bs4/css/dataTables.bootstrap4.min.css')); ?>" rel="stylesheet"
        type="text/css" />
    <link href="<?php echo e(asset('assets/libs/datatables.net-buttons-bs4/css/buttons.bootstrap4.min.css')); ?>" rel="stylesheet"
        type="text/css" />
    <!-- Select 2  -->
    <link href="<?php echo e(asset('assets/libs/select2/css/select2.min.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- Responsive datatable examples -->
    <link href="<?php echo e(asset('assets/libs/datatables.net-responsive-bs4/css/responsive.bootstrap4.min.css')); ?>"
        rel="stylesheet" type="text/css" />
    <!-- Pace -->
    <link href="<?php echo e(asset('assets/css/pace-theme-minimal.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- Filepond -->
    <link href="<?php echo e(asset('assets/libs/filepond/filepond.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/libs/filepond-plugin-image-preview/filepond-plugin-image-preview.min.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- Sweet Alert-->
    <link href="<?php echo e(asset('assets/libs/sweetalert2/sweetalert2.min.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- Bootstrap Css -->
    <link href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>" id="bootstrap-style" rel="stylesheet" type="text/css" />
    <!-- Icons Css -->
    <link href="<?php echo e(asset('assets/css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />
    <!-- App Css-->
    <link href="<?php echo e(asset('assets/css/app.min.css')); ?>" id="app-style" rel="stylesheet" type="text/css" />
    <script>
        const BASE_URL = "<?php echo e(url('/')); ?>"
        const ASSET_URL = "<?php echo e(asset('/')); ?>"
    </script>
    <style>
        .table-striped thead {
            background-color: #3b5de7;
            color: #ffffff;
        }
    </style>
</head>

<body data-layout="detached" data-topbar="colored">

    <?php echo $__env->yieldContent('app'); ?>
    
    <!-- JAVASCRIPT -->
    <script src="<?php echo e(asset('assets/libs/jquery/jquery.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/metismenu/metisMenu.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/simplebar/simplebar.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/node-waves/waves.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/jquery-sparkline/jquery.sparkline.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/chart.js/Chart.bundle.min.js')); ?>"></script>
    <!-- Pace  -->
    <script src="<?php echo e(asset('assets/js/pages/pace.min.js')); ?>"></script>
    <!-- Required datatable js -->
    <script src="<?php echo e(asset('assets/libs/datatables.net/js/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/datatables.net-bs4/js/dataTables.bootstrap4.min.js')); ?>"></script>
    <!-- Buttons examples -->
    <script src="<?php echo e(asset('assets/libs/datatables.net-buttons/js/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/datatables.net-buttons-bs4/js/buttons.bootstrap4.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/jszip/jszip.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/pdfmake/build/pdfmake.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/pdfmake/build/vfs_fonts.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/datatables.net-buttons/js/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/datatables.net-buttons/js/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/datatables.net-buttons/js/buttons.colVis.min.js')); ?>"></script>
    <!-- Responsive examples -->
    <script src="<?php echo e(asset('assets/libs/datatables.net-responsive/js/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/libs/datatables.net-responsive-bs4/js/responsive.bootstrap4.min.js')); ?>"></script>
    <!-- select 2  -->
    <script src="<?php echo e(asset('assets/libs/select2/js/select2.min.js')); ?>"></script>
    <!-- masonry-layout -->
    <script src="<?php echo e(asset('assets/libs/masonry-layout/masonry.pkgd.min.js')); ?>"></script>
    <!-- Sweet Alerts js -->
    <script src="<?php echo e(asset('assets/libs/sweetalert2/sweetalert2.min.js')); ?>"></script>
    <!-- Datatable init js -->
    <script src="<?php echo e(asset('assets/js/pages/datatables.init.js')); ?>"></script>
     <!-- filepond -->
    <script src='<?php echo e(asset('assets/libs/filepond/filepond.min.js')); ?>'></script>
    <script src='<?php echo e(asset('assets/libs/filepond-plugin-image-preview/filepond-plugin-image-preview.min.js')); ?>'></script>
    <script src="<?php echo e(asset('assets/libs/tinymce/tinymce.min.js')); ?>"></script>
    <!-- init js -->
    <script src="<?php echo e(asset('assets/js/pages/form-editor.init.js')); ?>"></script>
    <!-- Appexcharts js -->
    <script src="<?php echo e(asset('assets/libs/apexcharts/apexcharts.min.js')); ?>"></script>
    <!-- App js -->
    <script src="<?php echo e(asset('assets/js/app.js')); ?>"></script>
    

    <?php if(isset($mods)): ?>
        <?php if(is_array($mods)): ?>
            <?php $__currentLoopData = $mods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mod): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <script src="<?php echo e(asset('mods/mod_' . $mod . '.js')); ?>"></script>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <script src="<?php echo e(asset('mods/mod_' . $mods . '.js')); ?>"></script>
        <?php endif; ?>
    <?php endif; ?>

    <?php echo $__env->yieldContent('js'); ?>
</body>

</html>
<?php /**PATH C:\laragon\www\Sistem-Monitoring-TA\resources\views/administrator/layout/base.blade.php ENDPATH**/ ?>