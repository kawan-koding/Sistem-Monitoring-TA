<div class="modal fade" id="myModalUpload<?php echo e($item->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form action="" id="myUploadFileSeminar<?php echo e($item->id); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="modal-header">
                    <h5 class="modal-title mt-0" id="myModalLabelUploadFile">Unggah Berkas Seminar
                        Proposal
                    </h5>
                    <button type="button" class="btn btn-close" data-bs-dismiss="modal" aria-label="close"></button>
                </div>
                <div class="modal-body" style="position: relative">
                    <h5 class="text-start">1. Berkas Pendaftaran Seminar</h5>
                    <?php $__currentLoopData = $document_seminar->where('jenis', 'pra_seminar'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $document = $doc->pemberkasan()->where('tugas_akhir_id', $item->tugas_akhir->id)->first(); ?>
                        <div class="d-flex align-items-center gap-2 mb-3 " id="document<?php echo e($doc->id); ?>">
                            <?php if($document): ?>
                                <i class="file-icon bx bx-check-circle text-success"></i>
                            <?php else: ?>
                                <i class="file-icon mdi mdi-close-circle-outline text-danger"></i>
                            <?php endif; ?>
                            <div class="w-100 fw-bold text-start">
                                <?php echo e(ucwords(strtolower($doc->nama))); ?>

                                <?php if($document): ?>
                                    <p class="file-desc text-muted small m-0 p-0"><a
                                            href="<?php echo e(asset('storage/files/pemberkasan/' . $document->filename)); ?>"
                                            target="_blank">Lihat berkas</a></p>
                                <?php else: ?>
                                    <p class="file-desc text-muted small m-0 p-0"><i class="text-danger">*</i>)
                                        Belum ada berkas</p>
                                <?php endif; ?>
                            </div>
                            <label for="file<?php echo e($doc->id); ?>">
                                <input type="file" id="file<?php echo e($doc->id); ?>" onchange="changeFile('#document<?php echo e($doc->id); ?>')"
                                    name="document_<?php echo e($doc->id); ?>" class="d-none"  accept="<?php echo e($doc->tipe_dokumen == 'pdf' ? '.pdf' : 'image/*'); ?>" >
                                <?php if($document): ?>
                                    <div class="file-btn btn btn-outline-primary btn-sm">Perbarui</div>
                                <?php else: ?>
                                    <div class="file-btn btn btn-outline-primary btn-sm">Unggah</div>
                                <?php endif; ?>
                            </label>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <h5 class="text-start mt-4">2. Berkas Seminar</h5>
                    <?php $__currentLoopData = $document_seminar->where('jenis', 'seminar'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $document = $doc->pemberkasan()->where('tugas_akhir_id', $item->tugas_akhir->id)->first(); ?>
                        <div class="d-flex align-items-center gap-2 mb-3 " id="document<?php echo e($doc->id); ?>">
                            <?php if($document): ?>
                                <i class="file-icon bx bx-check-circle text-success"></i>
                            <?php else: ?>
                                <i class="file-icon mdi mdi-close-circle-outline text-danger"></i>
                            <?php endif; ?>
                            <div class="w-100 fw-bold text-start">
                                <?php echo e(ucwords(strtolower($doc->nama))); ?>

                                <?php if($doc->tipe_dokumen == 'gambar'): ?>
                                    <p class="fw-normal small mb-0">(Berkas harus berupa JPG/JPEG/PNG)</p>
                                <?php endif; ?>
                                <?php if($document): ?>
                                    <p class="file-desc text-muted small m-0 p-0"><a
                                            href="<?php echo e(asset('storage/files/pemberkasan/' . $document->filename)); ?>"
                                            target="_blank">Lihat berkas</a></p>
                                <?php else: ?>
                                    <p class="file-desc text-muted small m-0 p-0"><i class="text-danger">*</i>)
                                        Belum ada berkas</p>
                                <?php endif; ?>
                            </div>
                            <label for="file<?php echo e($doc->id); ?>">
                                <input type="file" id="file<?php echo e($doc->id); ?>" onchange="changeFile('#document<?php echo e($doc->id); ?>')"
                                    name="document_<?php echo e($doc->id); ?>" class="d-none"  accept=".pdf" >
                                <?php if($document): ?>
                                    <div class="file-btn btn btn-outline-primary btn-sm">Perbarui</div>
                                <?php else: ?>
                                    <div class="file-btn btn btn-outline-primary btn-sm">Unggah</div>
                                <?php endif; ?>
                            </label>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary waver-effect waves-light">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>

<div id="modalValidasiFile<?php echo e($item->id); ?>" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="validasiFileLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <form action="" id="validasiFileAction<?php echo e($item->id); ?>" method="post">
                <?php echo csrf_field(); ?>
                <div class="modal-header">
                    <h5 class="modal-title mt-0"> Validasi Berkas Seminar Proposal</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body text-start">
                    <h5 class="fw-bold">1. Berkas Pendaftaran Seminar</h5>
                    <div class="row">
                        <?php $__currentLoopData = $document_seminar->where('jenis', 'pra_seminar'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $document = $doc->pemberkasan()->where('tugas_akhir_id', $item->tugas_akhir->id)->first(); ?>
                            <div class="col-md-4 col-sm-6 col-12 border p-3" style="position: relative">
                                <div class="d-block text-center fw-bold" style="height: calc(100% - 115px);"><?php echo e(ucwords(strtolower($doc->nama))); ?></div>
                                <div class="d-flex align-items-center justify-content-center my-3" style="height: 50px">
                                    <?php if($document): ?>
                                        <i class="fa fa-file-pdf text-danger fa-3x"></i>
                                    <?php endif; ?>
                                </div>
                                <div class="text-center">
                                    <?php if($document): ?>
                                        <a href="<?php echo e(asset('storage/files/pemberkasan/' . $document->filename)); ?>" target="_blank" class="btn btn-secondary btn-sm">Lihat Berkas</a>
                                    <?php else: ?>
                                        <i class="text-danger">*</i>) Belum ada berkas
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <br><br>
                    <h5 class="fw-bold">2. Berkas Seminar</h5>
                    <div class="row">
                        <?php $__currentLoopData = $document_seminar->where('jenis', 'seminar'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $document = $doc->pemberkasan()->where('tugas_akhir_id', $item->tugas_akhir->id)->first(); ?>
                            <div class="col-md-4 col-sm-6 col-12 border p-3" style="position: relative">
                                <div class="d-block text-center fw-bold" style="height: calc(100% - 115px);"><?php echo e(ucwords(strtolower($doc->nama))); ?></div>
                                <div class="d-flex align-items-center justify-content-center my-3" style="height: 50px">
                                    <?php if($document): ?>
                                        <i class="fa fa-file-pdf text-danger fa-3x"></i>
                                    <?php endif; ?>
                                </div>
                                <div class="text-center">
                                    <?php if($document): ?>
                                        <a href="<?php echo e(asset('storage/files/pemberkasan/' . $document->filename)); ?>"  target="_blank" class="btn btn-secondary btn-sm">Lihat Berkas</a>
                                    <?php else: ?>
                                        <i class="text-danger">*</i>) Belum ada berkas
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <?php if($item->status == 'telah_seminar' && $item->tugas_akhir->status_pemberkasan != 'sudah_lengkap'): ?>
                    <div class="modal-footer">
                        <button class="btn btn-outline-success waves-effect"> <i class="fa fa-check-circle"></i> Berkas Lengkap</button>
                    </div>
                <?php endif; ?>
            </form>
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\Sistem-Monitoring-TA\resources\views/administrator/jadwal-seminar/partials/modal.blade.php ENDPATH**/ ?>