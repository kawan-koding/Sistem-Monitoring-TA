

<div class="row">
    <div class="col-md-4 col-sm-6 col-12">
        <div class="card shadow-sm border-primary" style="border-width: 0px 0px 0px 3px;">
            <div class="card-icon">
                <i class="fa fa-user"></i>
            </div>
            <div class="card-body">
                <h3 class="mb-2"><?php echo e($dosenCount); ?> </h3>
                <p class="mb-0">Total Dosen</p>
            </div>
        </div>
    </div>
    <div class="col-md-4 col-sm-6 col-12">
        <div class="card shadow-sm border-primary" style="border-width: 0px 0px 0px 3px;">
            <div class="card-icon">
                <i class="fa fa-users"></i>
            </div>
            <div class="card-body">
                <h3 class="mb-2"><?php echo e($mhsCount); ?> </h3>
                <p class="mb-0">Total Mahasiswa</p>
            </div>
        </div>
    </div>
    <div class="col-md-4 col-sm-6 col-12">
        <div class="card shadow-sm border-primary" style="border-width: 0px 0px 0px 3px;">
            <div class="card-icon">
                <i class="fa fa-book-open"></i>
            </div>
            <div class="card-body">
                <h3 class="mb-2"><?php echo e($taCount); ?> </h3>
                <p class="mb-0">Total Tugas Akhir</p>
            </div>
        </div>
    </div>

    
    <div class="col-md-3 col-sm-6 col-12">
        <div class="card shadow-sm border-primary text-white"
            style="border-width: 0px 0px 0px 3px;background: linear-gradient(to right, #3789f5, #222faa);">
            <div class="card-icon">
                <i class="bx bx-user-pin"></i>
            </div>
            <div class="card-body">
                <h3 class="mb-2"><?php echo e($mhsBelumMengajukanCount); ?> </h3>
                <p class="mb-0">Total Mahasiswa Belum Mengajukan</p>
            </div>
        </div>
    </div>
    <div class="col-md-3 col-sm-6 col-12">
        <div class="card shadow-sm border-primary text-white"
        style="border-width: 0px 0px 0px 3px;background: linear-gradient(to right, #3789f5, #222faa);">
        <div class="card-icon">
            <i class="bx bx-user-check"></i>
        </div>
            <div class="card-body">
                <h3 class="mb-2"><?php echo e($mhsBelumSeminarCount); ?> </h3>
                <p class="mb-0">Total Mahasiswa Belum Seminar</p>
            </div>
        </div>
    </div>
    <div class="col-md-3 col-sm-6 col-12">
        <div class="card shadow-sm border-primary text-white"
            style="border-width: 0px 0px 0px 3px;background: linear-gradient(to right, #3789f5, #222faa);">
            <div class="card-icon">
                <i class="bx bx-user-pin"></i>
            </div>
            <div class="card-body">
                <h3 class="mb-2"><?php echo e($mhsSudahSeminarCount); ?> </h3>
                <p class="mb-0">Total Mahasiswa Sudah Seminar</p>
            </div>
        </div>
    </div>
    <div class="col-md-3 col-sm-6 col-12">
        <div class="card shadow-sm border-primary text-white"
            style="border-width: 0px 0px 0px 3px;background: linear-gradient(to right, #3789f5, #222faa);">
            <div class="card-icon">
                <i class="bx bx-user-check"></i>
            </div>
            <div class="card-body">
                <h3 class="mb-2"><?php echo e($mhsSudahPemberkasanSeminarCount); ?> </h3>
                <p class="mb-0">Total Mahasiswa Sudah Pemberkasan Seminar</p>
            </div>
        </div>
    </div>

    <div class="col-md-3 col-sm-6 col-12">
        <div class="card shadow-sm border-primary text-white"
            style="border-width: 0px 0px 0px 3px;background: linear-gradient(to right, #3789f5, #222faa);">
            <div class="card-icon">
                <i class="bx bx-user-check"></i>
            </div>
            <div class="card-body">
                <h3 class="mb-2"><?php echo e($mhsDaftarSidangCount); ?> </h3>
                <p class="mb-0">Total Mahasiswa Daftar Sidang</p>
            </div>
        </div>
    </div>
    <div class="col-md-3 col-sm-6 col-12">
        <div class="card shadow-sm border-primary text-white"
            style="border-width: 0px 0px 0px 3px;background: linear-gradient(to right, #3789f5, #222faa);">
            <div class="card-icon">
                <i class="bx bx-user-pin"></i>
            </div>
            <div class="card-body">
                <h3 class="mb-2"><?php echo e($mhsBelumSidangCount); ?> </h3>
                <p class="mb-0">Total Mahasiswa Belum Sidang</p>
            </div>
        </div>
    </div>
    <div class="col-md-3 col-sm-6 col-12">
        <div class="card shadow-sm border-primary text-white"
            style="border-width: 0px 0px 0px 3px;background: linear-gradient(to right, #3789f5, #222faa);">
            <div class="card-icon">
                <i class="bx bx-user-check"></i>
            </div>
            <div class="card-body">
                <h3 class="mb-2"><?php echo e($mhsSudahSidangCount); ?> </h3>
                <p class="mb-0">Total Mahasiswa Sudah Sidang</p>
            </div>
        </div>
    </div>
    <div class="col-md-3 col-sm-6 col-12">
        <div class="card shadow-sm border-primary text-white"
            style="border-width: 0px 0px 0px 3px;background: linear-gradient(to right, #3789f5, #222faa);">
            <div class="card-icon">
                <i class="bx bx-user-pin"></i>
            </div>
            <div class="card-body">
                <h3 class="mb-2"><?php echo e($mhsSudahPemberkasanSidangCount); ?> </h3>
                <p class="mb-0">Total Mahasiswa Sudah Pemberkasan Sidang</p>
            </div>
        </div>
    </div>

</div>

<div class="row">
    <div class="col-md-8 col-sm-6 col-12">
        <div class="card shadow-sm mb-3" style="height: calc(100% - 1.5rem)">
            <div class="card-body">
                <h6 class="fw-bold">Statistik Kelulusan</h6>
                <div id="graduatedGraph" style="height: 350px"></div>
            </div>
        </div>
    </div>
    <div class="col-md-4 col-sm-6 col-12">
        <div class="card shadow-sm mb-3" style="height: calc(100% - 1.5rem)">
            <div class="card-body">
                <h6 class="fw-bold">Statistik Mahasiswa</h6>
                <div id="studentGraph" style="height: 350px"></div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\laragon\www\Sistem-Monitoring-TA\resources\views/administrator/dashboard/partials/admin.blade.php ENDPATH**/ ?>