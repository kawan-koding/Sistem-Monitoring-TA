
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-lg-6 col-md-6 col-sm-12">
            <div class="card">
                <div class="card-body">
                    <?php if(session('success')): ?>
                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                        <i class="mdi mdi-check-all me-2"></i> <?php echo e(session('success')); ?>

                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
                        </button>
                    </div>
                    <?php endif; ?>
                    <?php if(session('error')): ?>
                        <div class="alert alert-danger alert-dismissible fade show" role="alert">
                            <i class="mdi mdi-block-helper me-2"></i><?php echo e(session('error')); ?>

                            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
                            </button>
                        </div>
                    <?php endif; ?>
                    <?php if($errors->any()): ?>
                    <div class="alert alert-error alert-danger alert-dismissible fade show" role="alert">
                        <ul>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close">
                        </button>
                    </div>
                    <?php endif; ?>
                    
                    <form action="<?php echo e(route('apps.jadwal-sidang.update', ['jadwalSidang' => $jadwalSidang->id])); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="mb-3">
                            <label for="">Nama Mahasiswa<span class="text-danger"> *</span></label>
                            <input type="text" name="name" class="form-control" value="<?php echo e($editedData->tugas_akhir->mahasiswa->nim); ?> - <?php echo e($editedData->tugas_akhir->mahasiswa->nama_mhs); ?>" readonly>
                        </div>
                        <div class="mb-3">
                            <label for="">Ruangan<span class="text-danger"> *</span></label>
                            <select name="ruangan" class="form-control">
                                <option value="">Pilih Ruangan</option>
                                <?php $__currentLoopData = $ruangan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>" <?php echo e(isset($editedData) && $editedData->ruangan_id == $item->id || old('ruangan') == $item->id ? "selected" : ''); ?>><?php echo e($item->kode); ?>-<?php echo e($item->nama_ruangan); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="">Tanggal<span class="text-danger"> *</span></label>
                            <input type="date" name="tanggal" class="form-control" value="<?php echo e(old('tanggal', isset($editedData) ? $editedData->tanggal : '')); ?>">
                        </div>
                        <div class="mb-3">
                            <label for="">Jam Mulai<span class="text-danger"> *</span></label>
                            <input type="time" name="jam_mulai" class="form-control" value="<?php echo e(old('jam_mulai', isset($editedData) ? $editedData->jam_mulai : '')); ?>">
                        </div>
                        <div class="mb-3">
                            <label for="">Jam Selesai<span class="text-danger"> *</span></label>
                            <input type="time" name="jam_selesai" class="form-control" value="<?php echo e(old('jam_selesai', isset($editedData) ? $editedData->jam_selesai : '')); ?>">
                        </div>
                        <div class="mb-3">
                            <label for="">Dosen Pengganti Penguji 1</label>
                            <select name="pengganti1" class="form-control select2 dosen-select" onchange="updateOptions()">
                                <option value="">Pilih Dosen Penguji Pengganti</option>
                                <?php $__currentLoopData = $pengujiPengganti; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>" <?php echo e(isset($editedData) && !is_null($editedData->tugas_akhir->bimbing_uji()->where('jenis',  'pengganti')->where('urut', 1)->first()) && $editedData->tugas_akhir->bimbing_uji()->where('jenis',  'pengganti')->where('urut', 1)->first()->dosen_id == $item->id || old('pengganti1') == $item->id ? "selected" : ''); ?> <?php echo e(isset($editedData) && !is_null($editedData->tugas_akhir->bimbing_uji()->where('jenis',  'pengganti')->where('urut', 2)->first()) && $editedData->tugas_akhir->bimbing_uji()->where('jenis',  'pengganti')->where('urut', 2)->first()->dosen_id == $item->id || old('pengganti1') == $item->id ? "disabled" : ''); ?>>
                                        <?php echo e($item->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="">Dosen Pengganti Penguji 2</label>
                            <select name="pengganti2" class="form-control select2 dosen-select" onchange="updateOptions()">
                                <option value="">Pilih Dosen Penguji Pengganti</option>
                                <?php $__currentLoopData = $pengujiPengganti; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($item->id); ?>" <?php echo e(isset($editedData) && !is_null($editedData->tugas_akhir->bimbing_uji()->where('jenis',  'pengganti')->where('urut', 2)->first()) && $editedData->tugas_akhir->bimbing_uji()->where('jenis',  'pengganti')->where('urut', 2)->first()->dosen_id == $item->id || old('pengganti2') == $item->id ? "selected" : ''); ?> <?php echo e(isset($editedData) && !is_null($editedData->tugas_akhir->bimbing_uji()->where('jenis',  'pengganti')->where('urut', 1)->first()) && $editedData->tugas_akhir->bimbing_uji()->where('jenis',  'pengganti')->where('urut', 1)->first()->dosen_id == $item->id || old('pengganti2') == $item->id ? "disabled" : ''); ?>>
                                        <?php echo e($item->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <a href="<?php echo e(route('apps.jadwal-sidang')); ?>" class="btn btn-secondary">Kembali</a>
                        <button class="btn btn-primary" type="submit">Simpan</button>
                    </form>
                </div>
            </div>
        </div>
        <div class="col-md-6 col-sm-12">
            <div class="card">
                <div class="card-body">
                    <h4>Jadwal Mahasiswa Terdaftar</h4>
                    <hr class="mb-0">
                    <table class="table table-responsive">
                        <thead style="color: steelblue">
                            <th>Nama Mahasiswa</th>
                            <th>Jenis</th>
                            <th>Ruangan</th>
                            <th>Tanggal</th>
                            <th>Waktu</th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $mahasiswaTerdaftar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->tugas_akhir->mahasiswa->nama_mhs); ?></td>
                                <td><?php echo e($item->tugas_akhir->tipe == 'K' ? 'Kelompok' : 'Individu'); ?></td>
                                <td><?php echo e($item->ruangan->nama_ruangan); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($item->tanggal)->locale('id')->translatedFormat('l, d F Y')); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($item->jam_mulai)->locale('id')->translatedFormat('H:i')); ?> - <?php echo e(\Carbon\Carbon::parse($item->jam_selesai)->locale('id')->translatedFormat('H:i')); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
            
                <div class="card">
                    <div class="card-body">
                        <h4>Jadwal Dosen Terdaftar</h4>
                        <hr class="mb-3">
                        <div class="accordion" id="accordion">
                            <?php $__currentLoopData = $jadwalSidang->tugas_akhir->bimbing_uji; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($item->jenis == 'pembimbing' && $item->urut == 1): ?>
                                    <div class="accordion-item">
                                        <h2 class="accordion-header">
                                            <button class="accordion-button" type="button" data-bs-toggle="collapse"
                                                data-bs-target="#collapsePembimbing<?php echo e($item->urut); ?>" aria-expanded="true"
                                                aria-controls="collapsePembimbing<?php echo e($item->urut); ?>">
                                                <?php echo e($item->dosen->name); ?>

                                            </button>
                                        </h2>
                                        <div id="collapsePembimbing<?php echo e($item->urut); ?>" class="accordion-collapse collapse show"
                                            data-bs-parent="#accordion">
                                            <div class="accordion-body">
                                                <table class="table table-bordered">
                                                    <thead>
                                                        <tr>
                                                            <th>Tanggal</th>
                                                            <th>Jam Mulai</th>
                                                            <th>Jam Sesai</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php if($jadwalPembimbing1->count() > 0): ?>
                                                            <?php $__currentLoopData = $jadwalPembimbing1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <tr>
                                                                    <td><?php echo e($p1->tanggal); ?></td>
                                                                    <td><?php echo e($p1->jam_mulai); ?></td>
                                                                    <td><?php echo e($p1->jam_selesai); ?></td>
                                                                </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php else: ?>
                                                            <tr class="text-center">
                                                                <td colspan="3">Tidak ada data</td>
                                                            </tr>
                                                        <?php endif; ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                                <?php if($item->jenis == 'pembimbing' && $item->urut == 2): ?>
                                    <div class="accordion-item">
                                        <h2 class="accordion-header">
                                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                                data-bs-target="#collapsePembimbing<?php echo e($item->urut); ?>" aria-expanded="false"
                                                aria-controls="collapsePembimbing<?php echo e($item->urut); ?>">
                                                <?php echo e($item->dosen->name); ?>

                                            </button>
                                        </h2>
                                        <div id="collapsePembimbing<?php echo e($item->urut); ?>" class="accordion-collapse collapse"
                                            data-bs-parent="#accordion">
                                            <div class="accordion-body">
                                                <table class="table table-bordered">
                                                    <thead>
                                                        <tr>
                                                            <th>Tanggal</th>
                                                            <th>Jam Mulai</th>
                                                            <th>Jam Sesai</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php if($jadwalPembimbing2->count() > 0): ?>
                                                            <?php $__currentLoopData = $jadwalPembimbing2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <tr>
                                                                    <td><?php echo e($p2->tanggal); ?></td>
                                                                    <td><?php echo e($p2->jam_mulai); ?></td>
                                                                    <td><?php echo e($p2->jam_selesai); ?></td>
                                                                </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php else: ?>
                                                            <tr class="text-center">
                                                                <td colspan="3">Tidak ada data</td>
                                                            </tr>
                                                        <?php endif; ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                                <?php if($item->jenis == 'penguji' && $item->urut == 1): ?>
                                    <div class="accordion-item">
                                        <h2 class="accordion-header">
                                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                                data-bs-target="#collapsePenguji1<?php echo e($item->urut); ?>" aria-expanded="false"
                                                aria-controls="collapsePenguji1<?php echo e($item->urut); ?>">
                                                <?php echo e($item->dosen->name); ?>

                                            </button>
                                        </h2>
                                        <div id="collapsePenguji1<?php echo e($item->urut); ?>" class="accordion-collapse collapse"
                                            data-bs-parent="#accordion">
                                            <div class="accordion-body">
                                                <table class="table table-bordered">
                                                    <thead>
                                                        <tr>
                                                            <th>Tanggal</th>
                                                            <th>Jam Mulai</th>
                                                            <th>Jam Sesai</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php if($jadwalPenguji1->count() > 0): ?>
                                                            <?php $__currentLoopData = $jadwalPenguji1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <tr>
                                                                    <td><?php echo e($p1->tanggal); ?></td>
                                                                    <td><?php echo e($p1->jam_mulai); ?></td>
                                                                    <td><?php echo e($p1->jam_selesai); ?></td>
                                                                </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php else: ?>
                                                            <tr class="text-center">
                                                                <td colspan="3">Tidak ada data</td>
                                                            </tr>
                                                        <?php endif; ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                                <?php if($item->jenis == 'penguji' && $item->urut == 2): ?>
                                    <div class="accordion-item">
                                        <h2 class="accordion-header">
                                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                                                data-bs-target="#collapsePenguji1<?php echo e($item->urut); ?>" aria-expanded="false"
                                                aria-controls="collapsePenguji1<?php echo e($item->urut); ?>">
                                                <?php echo e($item->dosen->name); ?>

                                            </button>
                                        </h2>
                                        <div id="collapsePenguji1<?php echo e($item->urut); ?>" class="accordion-collapse collapse"
                                            data-bs-parent="#accordion">
                                            <div class="accordion-body">
                                                <table class="table table-bordered">
                                                    <thead>
                                                        <tr>
                                                            <th>Tanggal</th>
                                                            <th>Jam Mulai</th>
                                                            <th>Jam Sesai</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <?php if($jadwalPenguji2->count() > 0): ?>
                                                            <?php $__currentLoopData = $jadwalPenguji2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <tr>
                                                                    <td><?php echo e($p2->tanggal); ?></td>
                                                                    <td><?php echo e($p2->jam_mulai); ?></td>
                                                                    <td><?php echo e($p2->jam_selesai); ?></td>
                                                                </tr>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        <?php else: ?>
                                                            <tr class="text-center">
                                                                <td colspan="3">Tidak ada data</td>
                                                            </tr>
                                                        <?php endif; ?>
                                                    </tbody>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            
        </div>  
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('administrator.layout.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Sistem-Monitoring-TA\resources\views/administrator/jadwal-sidang/form.blade.php ENDPATH**/ ?>