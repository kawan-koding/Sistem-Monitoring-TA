

<?php $__env->startSection('main'); ?>
    <div class="main-content">

        <div class="page-content">
            <div class="row mb-5 mb-lg-0">
                <div class="col-12">
                    <div class="page-title-box d-flex align-items-center justify-content-between">
                        <h4 class="page-title mb-0 font-size-18"><?php echo e($title); ?></h4>

                            <?php if(isset($breadcrumbs)): ?>
                            <div class="page-title-right">
                                <ol class="breadcrumb m-0">
                                    <?php $__currentLoopData = $breadcrumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if(isset($item['is_active']) && $item['is_active']): ?>
                                            <li class="breadcrumb-item active"><?php echo e($item['title']); ?></li>
                                        <?php else: ?>
                                            <li class="breadcrumb-item"><a
                                                    href="<?php echo e($item['url']); ?>"><?php echo e($item['title']); ?></a></li>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ol>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            

            <?php echo $__env->yieldContent('content'); ?>

        </div>
        <!-- End Page-content -->

        <footer class="footer">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-6">
                        <?php echo e(getSetting('app_copyright')); ?>

                    </div>
                </div>
            </div>
        </footer>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('administrator.layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Sistem-Monitoring-TA\resources\views/administrator/layout/main.blade.php ENDPATH**/ ?>